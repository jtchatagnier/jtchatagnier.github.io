+-------------------------------------------+
| This file contains instructions for       |
| replicating the analysis in:              |
|                                           |
| "Does the WTO Exacerbate International    | 
| Conflict"                                 |
|                                           |
| By J. Tyson Chatagnier and Haeyong Lim    |
|                                           |
| Forthcoming in Journal of Peace Research  |
|                                           |
| File created 5 January 2020               |
+-------------------------------------------+

Contents
=========

 * WTO_Conflict_Appendix.pdf
   - PDF containing supplementary information and additional analyses not presented in the body of the article
 * wto_conflict_replication.txt
   - Text file containing output from running replication code
 * wto_conflict_replication_data.dta
   - Stata 13 .dta file, containing necessary information to replicate the analysis in the main text and most of the appendix
 * icb_robustness_replication_data.dta
   - Stata 13 .dta file, containing necessary information to replicate the alternative data (ICB) portion of the analysis in the appendix
 * wto_conflict_replication.r
   - R file used to replicate the results from the body of the article (lines 1--861) and the appendix (lines 862--1238)

Necessary Software
==================

 * R (analysis performed on R for Windows, v. 3.6.1)
 * R packages:
   - foreign
   - tidyverse
   - texreg
   - grid
   - gridExtra

Instructions
=============

1. Extract files to the relevant directory
2. Open wto_conflict_replication.r and insert directory information if necessary
3. Run file to replicate results (output will appear on screen)