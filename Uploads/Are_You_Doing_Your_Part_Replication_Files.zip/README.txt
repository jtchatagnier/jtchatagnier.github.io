---------------
---------------

Replication data for:

Klingler, Jonathan D. and J. Tyson Chatagnier. 2013.
"Are You Doing Your Part? Veterans' Political Attitudes, 
and Heinlein's Conception of Citizenship." 
_Armed Forces & Society_ Vol(Num): pp--pp.

---------------
---------------

Data files:
-----------
aydypreplicationdata.dta:	replication data for tables in paper

---------------
---------------

Replication files:
------------------
CCES_Recode_Replication.do:	Stata .do file to replicate aydypreplicationdata.dta from 
				the original file (available: 
				http://projects.iq.harvard.edu/cces/data).

Doing_Your_Part_Replication.R:	R code for replication of results in 
				Tables 1--5 in the paper.

---------------
---------------

Notes
-----

Stata code written using Stata 9.1
R code written using R 2.15.1
Data files are in Stata .dta format
Replication requires replacement of ~ in file path with directory name