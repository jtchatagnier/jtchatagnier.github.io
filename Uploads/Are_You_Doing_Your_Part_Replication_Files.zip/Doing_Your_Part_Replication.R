#########################################################
# R Code for replication of results:                    #
# Klingler, Jonathan D. and J. Tyson Chatagnier.        #
# "Are You Doing Your Part? Veterans' Political         #
# Attitudes, and Heinlein's Conception of Citizenship." #
# Published 2013 in Armed Forces & Society              #
#########################################################

rm(list=ls(all=TRUE))

library(foreign)

cces <- read.dta("~/aydypreplicationdata.dta")

                        # Read in replication data in Stat format.
cces$electorate <- 1
cces$novet <- ifelse(cces$veteran == 0, 1, 0)
                        # Create categories.


#########################
# Functions to be used. #
#########################

prop.calc <- function(X, Y){
                        # This function calculates the proportion of
                        # X = 1 for which Y = 1(X and Y both dichotomous).
    propmat <- na.omit(cbind(X, Y))
    prop.yes <- sum(propmat[, 1] * propmat[, 2])
    proportion <- prop.yes / sum(propmat[, 1])
    return(proportion)
}

median.calc <- function(X, Y){
                        # This function calculates the median value
                        # of Y for observations for which X = 1.
    mat <- cbind(X, Y)
    sub.mat <- subset(mat, mat[,1] == 1)
    median.mat <- median(na.omit(sub.mat)[, 2])
    return(median.mat)
}

diffprop.test <- function(X1, Y1, X2, Y2){
                        # This function performs a difference of proportions test
                        # for the proportion of X1 = 1 for which Y1 = 1 vs.
                        # the proportion of X2 = 1 for which Y2 = 1.
    p1 <- prop.calc(X1, Y1)
    p2 <- prop.calc(X2, Y2)
                        # Use the function above to calculate proportions.
    mat.1 <- na.omit(cbind(X1, Y1))
    mat.2 <- na.omit(cbind(X2, Y2))
    n1 <- sum(mat.1[, 1])
    n2 <- sum(mat.2[, 1])
    p.hat <- ((n1 * p1) + (n2 * p2)) / (n1 + n2)
    z.stat <- (p2 - p1) / sqrt((p.hat * (1 - p.hat) * ((1 / n1) + (1 / n2))))
                        # This puts a Z-statistic on our difference of proportions.
    if(z.stat > 1.96){
        cat("\n Group 1: ",p1, "\n Group 2: ",p2," \n Z-Statistic is",
        z.stat, "\n This means that the proportion is:
        significantly higher for group 2 than for group 1.\n")
    } else if(z.stat < -1.96){
        cat("\n Group 1: ", p1, "\n Group 2: ", p2, " \n Z-Statistic is",
        z.stat, "\n This means that the proportion is:
        significantly higher for group 1 than for group 2.\n")
    } else {
        cat("\n Group 1: ", p1, "\n Group 2: ", p2, " \n Z-Statistic is",
        z.stat, "\n We cannot distinguish between the two proportions.\n")
    }
                        # These lines output a user-friendly message to interpret the results.
}

###########
# Table 1 #
###########

sample.size <- 36249
                        # This is the size of the full 2006 CCES Survey.
                        # The full survey is not used here, but can be found at:
                        # http://projects.iq.harvard.edu/cces/

electorate.size <- sum(cces$electorate)
nonvet.size <- sum(cces$novet)
allvet.size <- sum(cces$veteran)
vet.size <- sum(cces$vol)
active.size <- sum(cces$current)

vals.tab1 <- as.matrix(c(sample.size, electorate.size, nonvet.size, allvet.size,
            vet.size, active.size))
rownames(vals.tab1) <- c("Sample", "Electorate", "Non-Veterans", "All Veterans", "Veterans", "Active Duty")
colnames(vals.tab1) <- c("Size")
as.table(vals.tab1)
                        # Rough replication of Table 1 from the paper.


###########
# Table 2 #
###########

propmale.vet <- prop.calc(cces$vol, cces$male)
n.male.vet <- sum(cces$vol) - sum(is.na(cces$male) & cces$vol == 1)
propwhite.vet <- prop.calc(cces$vol, cces$white)
n.white.vet <- sum(cces$vol) - sum(is.na(cces$white) & cces$vol == 1)
propblack.vet <- prop.calc(cces$vol, cces$black)
n.black.vet <- sum(cces$vol) - sum(is.na(cces$black) & cces$vol == 1)
propmarried.vet <- prop.calc(cces$vol, cces$married)
n.married.vet <- sum(cces$vol) - sum(is.na(cces$married) & cces$vol == 1)

propmale.elec <- prop.calc(cces$electorate, cces$male)
n.male.elec <- sum(cces$electorate) - sum(is.na(cces$male) & cces$electorate == 1)
propwhite.elec <- prop.calc(cces$electorate, cces$white)
n.white.elec <- sum(cces$electorate) - sum(is.na(cces$white) & cces$electorate == 1)
propblack.elec <- prop.calc(cces$electorate, cces$black)
n.black.elec <- sum(cces$electorate) - sum(is.na(cces$black) & cces$electorate == 1)
propmarried.elec <- prop.calc(cces$electorate, cces$married)
n.married.elec <- sum(cces$electorate) - sum(is.na(cces$married) & cces$electorate == 1)

row.1 <- round(c(propmale.vet, propwhite.vet, propblack.vet, propmarried.vet) * 100, 1)
row.2 <- c(n.male.vet, n.white.vet, n.black.vet, n.married.vet)
row.3 <- round(c(propmale.elec, propwhite.elec, propblack.elec, propmarried.elec) * 100, 1)
row.4 <- c(n.male.elec, n.white.elec, n.black.elec, n.married.elec)

vals.tab2 <- as.matrix(rbind(row.1, row.2, row.3, row.4))
rownames(vals.tab2) <- c("Veterans", "n", "Electorate", "n")
colnames(vals.tab2) <- c("Male", "White", "Black", "Married")
as.table(vals.tab2)
                        # Rough replication of Table 2 from the paper.
                        # Rows 1 and 3 represent percentages.

###########
# Table 3 #
###########

medage.vet <- median.calc(cces$vol, cces$age)
n.age.vet <- sum(cces$vol) - sum(is.na(cces$age) & cces$vol == 1)
medincome.vet <- median.calc(cces$vol, cces$income)
n.income.vet <- sum(cces$vol) - sum(is.na(cces$income) & cces$vol == 1)
medchurch.vet <- median.calc(cces$vol, cces$church)
n.church.vet <- sum(cces$vol) - sum(is.na(cces$church) & cces$vol == 1)
mededucation.vet <- median.calc(cces$vol, cces$education)
n.education.vet <- sum(cces$vol) - sum(is.na(cces$education) & cces$vol == 1)

medage.elec <- median.calc(cces$electorate, cces$age)
n.age.elec <- sum(cces$electorate) - sum(is.na(cces$age) & cces$electorate == 1)
medincome.elec <- median.calc(cces$electorate, cces$income)
n.income.elec <- sum(cces$electorate) - sum(is.na(cces$income) & cces$electorate == 1)
medchurch.elec <- median.calc(cces$electorate, cces$church)
n.church.elec <- sum(cces$electorate) - sum(is.na(cces$church) & cces$electorate == 1)
mededucation.elec <- median.calc(cces$electorate, cces$education)
n.education.elec <- sum(cces$electorate) - sum(is.na(cces$education) & cces$electorate == 1)

row.1 <- c(medage.vet, medincome.vet, medchurch.vet, mededucation.vet)
row.2 <- c(n.age.vet, n.income.vet, n.church.vet, n.education.vet)
row.3 <- c(medage.elec, medincome.elec, medchurch.elec, mededucation.elec)
row.4 <- c(n.age.elec, n.income.elec, n.church.elec, n.education.elec)

vals.tab2 <- as.matrix(rbind(row.1, row.2, row.3, row.4))
rownames(vals.tab2) <- c("Veterans", "n", "Electorate", "n")
colnames(vals.tab2) <- c("Age", "Income", "Church", "Education")
as.table(vals.tab2)
                        # Rough replication of Table 2 from the paper.
                        # Rows 1 and 3 give numerical medians.
                        # Corresponding categorical values can be found
                        # by referencing the CCES manual, included
                        # in the replication materials.

###########
# Table 4 #
###########

##########################################
# This section contains the code         #
# for checking the difference from the   #
# baseline category for each group, on   #
# each relevant question. A table can be #
# reconstructed from this information.   #
##########################################

diffprop.test(cces$vol, cces$partialbirth, cces$novet, cces$partialbirth)
diffprop.test(cces$vol, cces$partialbirth, cces$all, cces$partialbirth)

diffprop.test(cces$vol, cces$fundstemcell, cces$novet, cces$fundstemcell)
diffprop.test(cces$vol, cces$fundstemcell, cces$all, cces$fundstemcell)

diffprop.test(cces$vol, cces$citizenship, cces$novet, cces$citizenship)
diffprop.test(cces$vol, cces$citizenship, cces$all, cces$citizenship)

diffprop.test(cces$vol, cces$iraqtimetable, cces$novet, cces$iraqtimetable)
diffprop.test(cces$vol, cces$iraqtimetable, cces$all, cces$iraqtimetable)

diffprop.test(cces$vol, cces$minwagevote, cces$novet, cces$minwagevote)
diffprop.test(cces$vol, cces$minwagevote, cces$all, cces$minwagevote)

diffprop.test(cces$vol, cces$capitalgains, cces$novet, cces$capitalgains)
diffprop.test(cces$vol, cces$capitalgains, cces$all, cces$capitalgains)

diffprop.test(cces$vol, cces$cafta, cces$novet, cces$cafta)
diffprop.test(cces$vol, cces$cafta, cces$all, cces$cafta)

###########
# Table 5 #
###########

##########################################
# This section contains the code         #
# for checking the difference from the   #
# baseline category for each group, on   #
# each relevant question. A table can be #
# reconstructed from this information.   #
##########################################

diffprop.test(cces$vol, cces$oil, cces$novet, cces$oil)
diffprop.test(cces$vol, cces$oil, cces$all, cces$oil)
diffprop.test(cces$vol, cces$oil, cces$current, cces$oil)

diffprop.test(cces$vol, cces$terrcamp, cces$novet, cces$terrcamp)
diffprop.test(cces$vol, cces$terrcamp, cces$all, cces$terrcamp)
diffprop.test(cces$vol, cces$terrcamp, cces$current, cces$terrcamp)

diffprop.test(cces$vol, cces$genocide, cces$novet, cces$genocide)
diffprop.test(cces$vol, cces$genocide, cces$all, cces$genocide)
diffprop.test(cces$vol, cces$genocide, cces$current, cces$genocide)

diffprop.test(cces$vol, cces$democracy, cces$novet, cces$democracy)
diffprop.test(cces$vol, cces$democracy, cces$all, cces$democracy)
diffprop.test(cces$vol, cces$democracy, cces$current, cces$democracy)

diffprop.test(cces$vol, cces$allies, cces$novet, cces$allies)
diffprop.test(cces$vol, cces$allies, cces$all, cces$allies)
diffprop.test(cces$vol, cces$allies, cces$current, cces$allies)

diffprop.test(cces$vol, cces$un, cces$novet, cces$un)
diffprop.test(cces$vol, cces$un, cces$all, cces$un)
diffprop.test(cces$vol, cces$un, cces$current, cces$un)

diffprop.test(cces$vol, cces$never, cces$novet, cces$never)
diffprop.test(cces$vol, cces$never, cces$all, cces$never)
diffprop.test(cces$vol, cces$never, cces$current, cces$never)
