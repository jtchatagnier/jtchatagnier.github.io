#########################################################
# This is a program to replicate part 2 of the          #
# analyses for:                                         #
# Chatagnier, J. Tyson. "Teaching the Enemy: The        #
# Empirical Implications of Bargaining  Under           #
# Observation."                                         #
# Published in: The Journal of Conflict Resolution      #
#########################################################

library(foreign)
library(survival)

rm(list=ls())

disputes <- read.dta("~/tte_replication_2.dta")
source("~/duration_functions.R")

#setwd("~/")
                                # The program includes code to turn images
                                # into PDF files.
                                # These are currently commented out,
                                # but can be included.
                                # This line tells R into which directory to
                                # store the files.

##########################################
# Prepare the data for duration analysis #
##########################################

disputes$time.init <- days.calc(1816, 1, 1)
                                # Get a day count for the first day
                                # of the data set.
disputes$cens.rev <- ifelse(is.na(disputes$peacedays_a), 0, 1)
disputes$cens.norev <- ifelse(is.na(disputes$peacedays_b), 0, 1)
                                # Which values are censored?

disputes$peacedays_a <- ifelse(is.na(disputes$peacedays_a),
                            disputes$startday_dispute - disputes$time.init,
                            disputes$peacedays_a)
disputes$peacedays_b <- ifelse(is.na(disputes$peacedays_b),
                            disputes$startday_dispute - disputes$time.init,
                            disputes$peacedays_b)
                                # Data start on 01/01/1816. The first
                                # conflict for a state, after this
                                # date will have an NA. We will simply
                                # treat them as left-censored.

disputes$length.prevdisp.rescale <- disputes$prev_disp_length_b / 30
disputes$trade.rescale <- disputes$trade_b / 10000
                                # Rescaling previous dispute length and
                                # trade levels to avoid zero issues in
                                # coefficients.

peacelength.norev.surv <- Surv(disputes$peacedays_b, disputes$cens.norev)
                                # Create the survival object for the duration
                                # analysis.


############
# Analysis #
############

def.peace.dur <- coxph(peacelength.norev.surv ~ disputes$trade.rescale +
                    disputes$polity_b + disputes$rivals_b +
                    disputes$length.prevdisp.rescale +
                    disputes$rivals_b : disputes$length.prevdisp.rescale +
                    disputes$tenure_b + disputes$prev_disp_hiact_b,
                    subset = disputes$esc == 1)

summary(def.peace.dur)
                                # This is the initial analysis.

nphtest.def <- cox.zph(def.peace.dur)
nphtest.def
                                # Test for non-proportional hazards.
                                # p < .05 for:
                                # trade, rivalry, previous dispute length,
                                # leader tenure, and previous hostility level.

###########
# Table 2 #
###########

def.peace.nph <- coxph(peacelength.norev.surv ~
                    disputes$length.prevdisp.rescale +
                    disputes$length.prevdisp.rescale : disputes$log_time +
                    disputes$rivals_b + disputes$rivals_b : disputes$log_time +
                    disputes$rivals_b : disputes$length.prevdisp.rescale +
                    disputes$trade.rescale +
                    disputes$trade.rescale : disputes$log_time +
                    disputes$polity_b + disputes$tenure_b +
                    disputes$prev_disp_hiact_b +
                    disputes$prev_disp_hiact_b: disputes$log_time,
                    subset = disputes$esc == 1)
                                # Interaction of offending variables with
                                # log of time.

summary(def.peace.nph)

############
# Figure 4 #
############

time.length <- 365
nphvals <- matrix(c(def.peace.nph$coef[1], def.peace.nph$coef[7]), ncol = 2,
            byrow = T)
se.nph <- sqrt(diag(vcov(def.peace.nph)))[c(1, 7)]
nph.lo <- nphvals - (1.96 * se.nph)
nph.hi <- nphvals + (1.96 * se.nph)
length.time <- seq(from = 1, to = time.length)
lo.out <- out.cox.mult(nph.mat = nph.lo, n = time.length) / 30
hi.out <- out.cox.mult(nph.mat = nph.hi, n = time.length) / 30
                                # Need to divide by 30 to get the
                                # daily effect.

int.out <- cox.int(model = def.peace.nph, main.var = 1, int.var = 9,
            nph.var = 7, num.int = 4, num.out = time.length)
                                # This gives the estimates and CIs for the
                                # interaction between dispute length and
                                # rivalry.


#pdf("prevdisp.pdf", width = 7, height = 7)
plot.cox.mult(nph.mat = nphvals, n = time.length, y.lim = c(-0.08, 0.08),
            plot.title = "Daily Effect of Defender's Previous Dispute
            \n Length with No Outside Rivals", daily = T)
polygon(c(length.time, rev(length.time)), c(lo.out, rev(hi.out)),
        col = rgb(0, 0, 0, alpha = 0.25), border = rgb(0, 0, 0, alpha = 0.25))
abline(h = 0, lty = 2, lwd = 2)
                                # This is the left panel.
#dev.off()

#pdf("prevdispriv.pdf", width = 7, height = 7)
plot(length.time, int.out$est, ylim = c(min(int.out$lo), -min(int.out$lo) / 2),
        main = "Daily Effect of Defender's Previous Dispute \n Length with
        Four Outside Rivals", type = "l", lwd = 2,
        xlab = "Days Since Last Conflict", ylab = "Percent Change in Hazard")
polygon(c(length.time, rev(length.time)), c(int.out$lo, rev(int.out$hi)),
        col = rgb(0, 0, 0, alpha = 0.25), border = rgb(0, 0, 0, alpha = 0.25))
abline(h = 0, lty = 2, lwd = 2)
                                # This is the left panel.
#dev.off()
