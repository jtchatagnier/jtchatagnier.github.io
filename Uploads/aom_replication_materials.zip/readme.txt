+----------------------------------------------+
| This file contains instructions for          |
| replicating the analysis in:                 |
|                                              |
| "The Arc of Modernization: Economic          |
| Structure, Materialism, and the Onset        |
| of Civil Conflict"                           |
|                                              |
| By J. Tyson Chatagnier and Emanuele Castelli |
|                                              |
| Forthcoming in Political Science             |
| Research & Methods                           |
|                                              |
| File created 1 April 2016                    |
+----------------------------------------------+

Contents
=========

 * koubi_boehmelt_jpr_replication.dta
   - Stata data file, containing replication materials drawn from Koubi and Boehmelt's 2014 JPR article
 * state_data.dta
   - Stata data file, containing information on Polity scores, per capita GDP, sectoral value added, and urbanization
 * fem_pop_25_over.dta
   - Stata data file, containing information on female education in various countries, drawn from the Barro-Lee Educational Attainment Data set
 * civil_peace_data_and_pca.r
   - R code to run PCA and create a data set for analysis; replicates Figures 2 and 3 as well as the right panels of Figures 5 and 6
 * sppo_replication.do
   - Stata DO file to perform analysis and replicate Table 2
 * sppo_substantive_replication.r
   - R code to examine substantive results and replicate Figure 4, as well as the left panels of Figures 5 and 6

Instructions
=============

1. Extract files to the relevant directory
2. Open civil_peace_data_and_pca.r and insert directory information if necessary
3. Run file to create the following:
 - pca_plot.pdf (Figure 2)
 - pca_plot_korea.pdf (top-left quadrant of Figure 3)
 - pca_plot_brazil.pdf (top-right quadrant of Figure 3)
 - pca_plot_uk.pdf (bottom-left quadrant of Figure 3)
 - pca_plot_mali.pdf (bottom-right quadrant of Figure 3)
 - pca_plot_mexico.pdf (right panel of Figure 5)
 - pca_plot_chile.pdf (right panel of Figure 6)
 - cw_replication_data.dta (complete data set)
4. Open sppo_replication.do and insert directory information if necessary
5. Run file to replicate results from Table 2 and to generate two text files to be used in step 7:
 - sppo_coefs_final.txt
 - sppo_vcov_final.txt
6. Open sppo_substantive_replication.r and insert directory information if necessary
7. Run file to create the following:
 - mod_mat_3d.pdf (Figure 4)
 - chile_sppo.pdf (left panel of Figure 5)
 - meixco_sppo.pdf (left panel of Figure 6)