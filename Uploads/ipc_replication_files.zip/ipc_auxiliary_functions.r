###############################################
# Auxiliary functions used in code for:       #
#                                             #
# "The internationalization of production and #
# compliance in WTO disputes"                 #
#                                             #
# Aydin Yildirim, J. Tyson Chatagnier,        #
# Arlo Poletti, and Dirk De Bievre            #
#                                             #
# Forthcoming in the Review of International  #
# Organizations                               #
#                                             #
# File created 10 March 2017                  #
###############################################

#####################
# Plotting function #
#####################

plot.cox.mult <- function(mod.cox,
                          var.main,
                          var.nph   = NULL,
                          n         = 36,
                          size.line = 1.10,
                          col.line  = "blue"
                          ) {
                       # mod.cox is a fitted Cox PH model.
                       # var.main is the position of the variable 
                       # in whose effect we are interested.
                       # var.nph, if input, is position of
                       # the interaction with time for a variable 
                       # with NP effects.
  x.time <- log(seq(1 : n))
  if (is.null(var.nph)) {
    change <- 100 * (exp(coef(mod.cox)[var.main]) - 1)
    se.var <- sqrt(diag(vcov(mod.cox)))[var.main]
    lo <- 100 * (exp(coef(mod.cox)[var.main] - 1.96 * se.var) - 1)
    hi <- 100 * (exp(coef(mod.cox)[var.main] + 1.96 * se.var) - 1)
  } else {
    xb <- coef(mod.cox)[var.main] + (coef(mod.cox)[var.nph] * x.time)
    se.nph <- sqrt(vcov(mod.cox)[var.main, var.main] + 
                   vcov(mod.cox)[var.nph, var.nph] +
                   2 * vcov(mod.cox)[var.main, var.nph]
                   )
    xb.lo <- xb - 1.96 * se.nph
    xb.hi <- xb + 1.96 * se.nph
    change <- 100 * (exp(xb) - 1)
    lo <- 100 * (exp(xb.lo) - 1)
    hi <- 100 * (exp(xb.hi) - 1)
  }
                        # If we have a proportional hazard, then we simply
                        # calculate the percentage change; otherwise, we 
                        # make use of the interaction.
  plot.df <- data.frame(time   = exp(x.time),
                        effect = change,
                        lo     = lo,
                        hi     = hi
                        )
  ggplot(data = plot.df,
           aes(x = time,
               y = effect
               )
           ) +
    geom_line(size   = size.line,
              colour = col.line
              ) +
    geom_ribbon(aes(ymin = lo,
                    ymax = hi,
                    ),
                fill   = col.line,
                alpha  = 0.3,
                colour = NA
                ) +
    geom_hline(yintercept = 0,
               linetype   = 2,
               size       = 1
               ) +
                        # Dashed line at zero.
    theme_bw()
}

########################
# Convenience function #
########################

substrRight <- function(x, 
                        n
                        ){
  substr(x, 
         nchar(x) - n + 1, 
         nchar(x)
         )
}

#####################################
# Functions for implementing Kropko #
# and Harden's method               #
#####################################

PlotGAM <- function(mod,
                    x        = NULL,
                    y        = NULL,
                    ci       = 1.96
                    ) {
  require(ggplot2)
  if (class(mod) != "coxph") {
    stop("'mod' must be of type 'coxph'")
  }
  require(mgcv)
  if (is.null(x)) {
    x <- mod$x
  }
  if (is.null(y)) {
    y <- mod$y
  }
  b <- mod$coef
  n <- nrow(x)
                        # Need to use number of rows in x, rather than
                        # length of y for reasons below.
  censored <- which(as.numeric(y)[(n + 1) : (2 * n)] == 0)
                        # Objects of class Surv are of length 2n, such that
                        # the first n are durations, and the second n are
                        # indicators for whether failure was reached.
  if (length(censored) > 0) {
    x <- x[-censored, ]
    y <- y[-c(censored, (censored + n))]
  }
  y <- as.numeric(y)[1 : (n - length(censored))]
                        # We want y simply to be numeric now, rather than
                        # an object of class Surv.    
  lin.pred <- exp(x %*% b)
  rank.lin <- rank(lin.pred)
  gam.out <- gam(y ~ s(rank.lin,
                       bs = "cr"
                       )
                 )
  pred <- predict(gam.out,
                  se = TRUE
                  )
  gam.df <- data.frame(x   = rank.lin,
                       y   = y,
                       fit = pred$fit,
                       lo  = pred$fit - ci * pred$se,
                       hi  = pred$fit + ci * pred$se
                       )
  p <- ggplot(data = gam.df,
              aes(x = x,
                  y = y
                  )
              ) +
         geom_point(col = "gray") +
         geom_line(aes(x = x,
                       y = fit
                       ),
                   size = 1.1
                   ) +
          geom_ribbon(aes(ymin = lo,
                          ymax = hi,
                          ),
                alpha  = 0.3,
                colour = NA
                ) +
          xlab("Expected Rank") +
          ylab("True Duration")
  print(p)
}

GetDur <- function(mod,
                   vec      = NULL,
                   x        = NULL,
                   y        = NULL,
                   var      = NULL,
                   vals     = NULL
                   ) {
  if (class(mod) != "coxph") {
    stop("'mod' must be of type 'coxph'")
  }
  require(mgcv)
  if (is.null(x)) {
    x <- mod$x
  }
  if (is.null(y)) {
    y <- mod$y
  }
  b <- mod$coef
  n <- nrow(x)
                        # Need to use number of rows in x, rather than
                        # length of y for reasons below.
  censored <- which(as.numeric(y)[(n + 1) : (2 * n)] == 0)
                        # Objects of class Surv are of length 2n, such that
                        # the first n are durations, and the second n are
                        # indicators for whether failure was reached.
  if (length(censored) > 0) {
    x <- x[-censored, ]
    y <- y[-c(censored, (censored + n))]
  }
  y <- as.numeric(y)[1 : (n - length(censored))]
                        # We want y simply to be numeric now, rather than
                        # an object of class Surv.    
  lin.pred <- exp(x %*% b)
  rank.lin <- rank(lin.pred)
  gam.out <- gam(y ~ s(rank.lin,
                       bs = "cr"
                       )
                 )
  if(is.null(vec)) {
    if (is.character(var)) {
      var <- which(names(coef(mod)) %in% var)
    }
    for (i in 1 : length(vals)) {
      x.c <- x
      x.c[, var] <- vals[i]
      lp <- exp(x.c %*% b)
      lin.pred <- rbind(lin.pred,
                        median(lp)
                        )
    }
      rl <- rank(lin.pred)
  } else {
    x.c <- matrix(vec,
                  ncol  = length(vec),
                  nrow  = length(vals),
                  byrow = TRUE
                  )
    if (is.character(var)) {
      var <- which(names(coef(mod)) %in% var)
    }
    x.c[, var] <- vals
    lp <- exp(x.c %*% b)
    rl <- rank(rbind(lin.pred,
                     lp[1]
                     )
               )
    for (i in 2 : length(lp)) {
      rl <- c(rl,
              tail(rank(rbind(lin.pred,
                              as.matrix(lp[(i - 1) : i])
                              )
                        ),
                   1
                   )
              )
      }
                        # We can't look at many values at once,
                        # because the rank will get messed up for
                        # large values of X. So we'll look at two
                        # at a time.
  }
  pred <- predict(gam.out,
                  newdata = data.frame(rank.lin = rl)
                  )
  pred.vec <- tail(pred,
                   length(vals)
                   )
  return(pred.vec)
}

BootDur <- function(mod,
                    vec      = NULL,
                    var      = NULL,
                    vals     = NULL,
                    m        = 1000,
                    ci       = 1.96,
                    se       = FALSE
                    ) {
  n <- nrow(mod$x)
  pe <- GetDur(mod      = mod,
               vec      = vec,
               var      = var,
               vals     = vals
               )
  dur.boot <- matrix(nrow = m,
                     ncol = length(vals)
                     )
  for (i in 1 : m) {
    rows <- sample(n,
                   replace = TRUE
                   )
    dur.boot[i, ] <- GetDur(mod      = mod,
                            vec      = vec,
                            x        = mod$x[rows, ],
                            y        = mod$y[rows],
                            var      = var,
                            vals     = vals
                            )
  }
  .se <- apply(dur.boot,
               2,
               sd
               )
  lo <- apply(dur.boot,
              2,
              quantile,
              prob = 0.025
              )
  hi <- apply(dur.boot,
              2,
              quantile,
              prob = 0.975
              )
  if (se == TRUE) {
    return(list(point = pe,
                se    = .se,
                lo    = lo,
                hi    = hi,
                boot  = dur.boot
                )
       )    
  } else {
    return(list(point = pe,
                lo    = lo,
                hi    = hi,
                boot  = dur.boot
                )
           )    
  }
}

PlotDur <- function(mod,
                    vec      = NULL,
                    var      = NULL,
                    vals     = NULL,
                    m        = 1000,
                    ci       = 1.96,
                    size     = 1.10,
                    boot     = TRUE
                    ) {
  require(ggplot2) 
  if (boot == TRUE) {
    boot.est <- BootDur(mod      = mod,
                        vec      = vec,
                        var      = var,
                        vals     = vals,
                        m        = m,
                        ci       = ci
                        )
    dur.df <- data.frame(Duration = boot.est$point,
                         Change   = vals,
                         Lo       = boot.est$lo,
                         Hi       = boot.est$hi
                         )

  } else {
    boot.est <- BootDur(mod      = mod,
                        vec      = vec,
                        var      = var,
                        vals     = vals,
                        m        = m,
                        ci       = ci,
                        se       = TRUE
                        )
    dur.df <- data.frame(Duration = boot.est$point,
                         Change   = vals,
                         Lo       = boot.est$point - boot.est$se,
                         Hi       = boot.est$point + boot.est$se
                         )
  }
  p <- ggplot(data = dur.df,
              aes(x = Change,
                  y = Duration
                  )
              ) +
         geom_line(size   = size,
                   colour = "navyblue"
                   ) +
         geom_ribbon(aes(ymin = Lo,
                         ymax = Hi
                         ),
                     alpha  = 0.3,
                     colour = NA
                     )
}
