###########################################################
# This file contains code to replicate                    #
# all tables and figures in:                              #
#                                                         #
# "Would You Like to Know More? Selection, Socialization, # 
#  and the Political Attitudes of Military Veterans?"     #
#                                                         #
# By: J. Tyson Chatagnier and Jonathan D. Klingler        #
#                                                         #
# Forthcoming in Political Research Quarterly             #
#                                                         #
# File created 12 July 2022                               #
###########################################################

rm(list = ls())

library(psych)
library(tidyverse)
library(MatchIt)
library(cobalt)
library(sensemakr)
library(texreg)

##########################
# Write set of functions #
# for use later          #
##########################

PlotRes <- function(
                    list_res,
                    names_res = NULL,
                    symmetric = FALSE
                    ) {
  require(ggplot2)

  if (is.null(names_res)) {
  var_names <- paste(
                     "Model", 
                     seq(
                         1,
                         length(list_res)
                         )
                     )
  } else {
    if (length(list_res) != length(names_res)) {
      stop("names_res and list_res arguments unequal lengths.")
    } else {
      var_names <- names_res
    }
  }

  results <- lapply(
                    list_res, 
                    function(x) { 
                      coef(summary(x))
                    }
                    )
                        # This will extract the second column of the
                        # result table for each model in the list. This
                        # column should be related to our variable of 
                        # interest.
  estimate <- sapply(
                     results,
                     function(x) {
                      x[2, 1]
                     }
                     )
  se <- sapply(
               results,
               function(x) {
                x[2, 2]
               }
               )
  res_df <- data.frame(
                       b   = estimate,
                       lo  = estimate - 1.96 * se,
                       lo2 = estimate - 1.645 * se,
                       hi  = estimate + 1.96 * se,
                       hi2 = estimate + 1.645 * se,
                       number = rev(
                                    seq(
                                        from = 1, 
                                        to   = length(estimate)
                                        )
                                    )
                       )
  
  x_lo <- ifelse(
                 min(res_df$lo) < 0,
                 -ceiling(abs(min(res_df$lo))),
                 0
                 )
                       # If the smallest value of res_df$lo is negative, then
                       # we round to the next smallest integer. If it's
                       # positive, then we simply use 0.
  x_hi <- ifelse(
                 max(res_df$hi) > 0,
                 ceiling(max(res_df$hi)),
                 0
                 )
                       # If the largest value of res_df$hi is positive, then
                       # we round up to the next largest integer. Otherwise
                       # we use 0.
  x_axis <- c(
              x_lo,
              x_hi
              )
  
  if(symmetric == TRUE) {
    x_axis <- c(
                -max(
                     abs(
                         c(
                           x_lo,
                           x_hi
                           )
                         )
                     ),
                max(
                    abs(
                        c(
                          x_lo,
                          x_hi
                          )
                        )
                    )
                )
  }
  if (nrow(res_df) == 2) {
    ylims <- c(
               0, 
               3
               )
  } else {
    ylims <- c(
               min(res_df$number),
               max(res_df$number)
               )
  }
                        # Use this to keep the plot from
                        # looking terrible if we only have
                        # two things to plot.
  lims <- ifelse(
                 nrow(res_df) == 2,
                 c(
                   0, 
                   3
                   ),
                 c(
                   min(res_df$number),
                   max(res_df$number)
                   )
                 )
  plot_out <- ggplot(data = res_df) +
                        # Initialize the plot.
                geom_vline(
                           xintercept = 0,
                           linetype   = 2
                           ) +
                        # Dashed line at zero.
                geom_point(
                           aes(
                               x = estimate,
                               y = number
                               ),
                           size  = 5,
                           color = "darkblue"
                           ) +
                        # Plot coefficients.
                geom_segment(
                             aes(
                                 x    = lo,
                                 xend = hi,
                                 y    = number,
                                 yend = number
                                 ),
                             size    = 2,
                             lineend = "round",
                             color   = "darkblue"
                             ) +
                geom_segment(
                             aes(
                                 x    = lo2,
                                 xend = hi2,
                                 y    = number,
                                 yend = number
                                 ),
                             size    = 3,
                             lineend = "round",
                             color   = "darkblue"
                             ) +
                        # Plot confidence intervals
                scale_x_continuous(
                                   limits = x_axis,
                                   name   = "Estimated Effect",
                                   breaks = 0.9 * x_axis,
                                   labels = c(
                                              "More\nliberal",
                                              "More\nconservative"
                                              )
                                   ) +
                scale_y_continuous(
                                   limits = ylims,
                                   name   = "",
                                   breaks = res_df$number,
                                   labels = var_names
                                   ) +
                theme_bw() +
                theme(
                      axis.text    = element_text(size = 17),
                      axis.title   = element_text(size = 17),
                      legend.text  = element_text(size = 17),
                      legend.title = element_text(size = 17),
                      title        = element_text(size = 15)
                      )
  return(plot_out)
}

PlotMult <- function(
                     res_list,
                     names_res,
                     group_names,
                     levs        = NULL,
                     symmetric   = FALSE
                     ) {
  require(ggplot2)
  results <- lapply(
                    res_list, 
                    function(x) { 
                      coef(summary(x))
                    }
                    )
                        # This will extract the second column of the
                        # result table for each model in the list. This
                        # column should be related to our variable of 
                        # interest.
  val <- sapply(
                results,
                function(x) {
                  x[2, 1]
                }
                )
  se <- sapply(
               results,
               function(x) {
                 x[2, 2]
               }
               )
  res_df <- data.frame(
                       val   = val,
                       lo     = val - 1.96 * se,
                       lo2    = val - 1.645 * se,
                       hi     = val + 1.96 * se,
                       hi2    = val + 1.645 * se,
                       group = group_names,
                       mod   = names_res
                       )

  res_df$mod_num <- as.numeric(
                               factor(
                                      res_df$mod,
                                      levels = unique(res_df$mod)
                                      )
                               )

  if (!is.null(levs)) {
    res_df$group <- factor(
                           res_df$group, 
                           levels = levs
                           )
                        # Ensure that the legend starts with raw
  }
  res_df <- res_df %>% 
              group_by(mod) %>% 
                mutate(
                       y_pos = as.numeric(mod_num) + 
                               (
                                mean(as.numeric(group)) -
                                as.numeric(group)
                                ) / 5
                       )

  x_lims <- c(
              res_df$lo,
              res_df$hi
              )

  x_lo <- ifelse(
                 min(x_lims) < 0,
                 -ceiling(abs(min(x_lims))),
                 0
                 )
                       # If the smallest value of res_df$lo is negative, then
                       # we round to the next smallest integer. If it's
                       # positive, then we simply use 0.
  x_hi <- ifelse(
                 max(x_lims) > 0,
                 ceiling(max(x_lims)),
                 0
                 )
                       # If the largest value of res_df$hi is positive, then
                       # we round up to the next largest integer. Otherwise
                       # we use 0.
  x_axis <- c(
              x_lo,
              x_hi
              )
  
  if(symmetric == TRUE) {
    x_axis <- c(
                -max(
                     abs(
                         c(
                           x_lo,
                           x_hi
                           )
                         )
                     ),
                max(
                    abs(
                        c(
                          x_lo,
                          x_hi
                          )
                        )
                    )
                )
  }
  ylims <- c(
             min(res_df$y_pos) - 0.2,
             max(res_df$y_pos) + 0.2
             )
  var_names <- unique(res_df$mod)
  lab_pos <- unique(as.numeric(res_df$mod_num))
  plot_out <- ggplot(data = res_df) +
                        # Initialize the plot.
                geom_vline(
                           xintercept = 0,
                           linetype   = 2
                           ) +
                        # Dashed line at zero.
                geom_point(
                           aes(
                               x      = val,
                               y      = y_pos,
                               colour = group,
                               shape  = group
                               ),
                           size  = 5
                           ) +
                        # Plot coefficients.
                geom_segment(
                             aes(
                                 x      = lo,
                                 xend   = hi,
                                 y      = y_pos,
                                 yend   = y_pos,
                                 colour = group
                                 ),
                             size    = 2,
                             lineend = "round"
                             ) +
                geom_segment(
                             aes(
                                 x      = lo2,
                                 xend   = hi2,
                                 y      = y_pos,
                                 yend   = y_pos,
                                 colour = group
                                 ),
                             size    = 3,
                             lineend = "round"
                             ) +
                        # Plot confidence intervals
                scale_x_continuous(
                                   limits = x_axis,
                                   name   = "Estimated Effect",
                                   breaks = 0.9 * x_axis,
                                   labels = c(
                                              "More\nliberal",
                                              "More\nconservative"
                                              )
                                   ) +
                scale_y_continuous(
                                   limits = ylims,
                                   name   = "",
                                   breaks = lab_pos,
                                   labels = var_names
                                   ) +
                # scale_shape_manual(
                #                    values = c(
                #                               16,
                #                               15
                #                               )
                #                    ) +
                # scale_color_manual(
                #                    values = c(
                #                               "red",
                #                               "black"
                #                               )
                #                    ) +
                theme_bw() +
                theme(
                      axis.text    = element_text(size = 17),
                      axis.title   = element_text(size = 17),
                      legend.text  = element_text(size = 12),
                      legend.title = element_text(size = 12),
                      title        = element_text(size = 15)
                      )
  return(plot_out)
}

GetStats <- function(
                     df,
                     stat
                     ) {
  if (stat == "length") {
    df_stat <- apply(
                     df, 
                     2, 
                     function (x) {
                       sum(!is.na(x))
                     }
                     )
  } else {
  df_stat <- apply(
                   df,
                   2,
                   stat,
                   na.rm = TRUE
                   )
  }
  return(df_stat)
}

MakeTable <- function(
                      vars,
                      var_names,
                      index = TRUE
                      ) {
  var_ind <- rowSums(vars) %>%
               na.omit()
  var_df <- data.frame(
                       Variable     = var_names,
                       Observations = GetStats(
                                               vars,
                                               "length"
                                               ),
                       Minimum      = GetStats(
                                               vars,
                                               "min"
                                               ),
                       Mean         = GetStats(
                                               vars,
                                               "mean"
                                               ),
                       Maximum      = GetStats(
                                               vars,
                                               "max"
                                               ),
                       StDev        = GetStats(
                                               vars,
                                               "sd"
                                               ),
                       Alpha        = NA
                       )
  var_nona <- na.omit(vars)
  if (index == TRUE) {
    var_df <- rbind(
                    var_df,
                    c(
                      "Index",
                      length(var_ind),
                      min(var_ind),
                      mean(var_ind),
                      max(var_ind),
                      sd(var_ind),
                      psych::alpha(var_nona)$total$raw_alpha
                      )
                    ) 
    var_df[, -1] <- sapply(
                           var_df[, -1], 
                           function (x) { 
                             as.numeric(x) 
                           }
                           )
  }
  print(var_df, digits = 2)
}

WeaveRes <- function(res_list) {
  coef_list <- lapply(
                      res_list,
                      summary
                      ) %>% 
                 lapply(coef)
  coef_est <-  coef_list %>% 
                 lapply(
                        `[`,
                        2,
                        1
                        ) %>%
                   unlist() %>%
                     round(digits = 2)

  se_est <-  coef_list %>% 
               lapply(
                      `[`,
                      2,
                      2
                      ) %>%
                 unlist() %>%
                   round(digits = 2) %>%
                     paste0(
                            "(",
                            .,
                            ")"
                            )
  vec_weave <- c(
                 rbind(
                       coef_est,
                       se_est
                       )
                 )

  return(vec_weave)
}

GetRes <- function(
                   vet_sub,
                   sub_cat
                   ) {
  for (i in 1 : length(mods)) {
    vet_name <- paste(
                      mods[i],
                      "_vet_",
                      sub_cat,
                      sep = ""
                      )
    vet_form <- paste(
                      dvs[i],
                      iv_vet,
                      sep = " "
                      ) %>%
                  as.formula()
  
    assign(
           vet_name,
           lm(
              vet_form,
              data    = vet_sub,
              weights = weights
              ),
           envir = .GlobalEnv
           )
  }
}

##################################
# Read in data and run analysis. #
##################################

vets <- read.csv("wyltkm_replication_data.csv")
                        # Read in replication data.

# setwd()
                        # Uncomment to change the working directory.


vets[vets < 0] <- NA
                        # We have no legitimate negative values in our
                        # data. Missing values are coded either -1 or
                        # -9. Turn those into NAs.
dvs <- c(
         "pid",
         "ideo",
         "social",
         "economic"
         )
                        # List of dependent variables from the data
                        # set, which will be useful later.

###############################
# Create additive indices     #
# for the various issue types #
###############################

soc_ind <- cbind(
                 vets$vouchers,
                 vets$abortion,
                 vets$title.ix,
                 vets$prayer,
                 vets$ssm
                 )

psych::alpha(soc_ind)

soc_ind <- rowSums(soc_ind)

econ_ind <- cbind(
                  vets$redist,
                  vets$spending,
                  vets$cut_mil,
                        ## We can remove this to create an index
                        ## uncontaminated by military issues.
                  vets$tariffs,
                  vets$inflation,
                  vets$obamacare
                  )

psych::alpha(econ_ind)

econ_ind <- rowSums(econ_ind)

vets$social <- soc_ind
vets$economic <-econ_ind

#########################
# Create summary tables #
#########################

ideo_table <- MakeTable(
                        vars      = cbind(
                                          vets$pid,
                                          vets$ideo
                                          ),
                        var_names = c(
                                      "Party ID",
                                      "Ideology"
                                      ),
                        index     = FALSE
                        )

soc_table <- MakeTable(
                       vars = cbind(
                                    vets$vouchers,
                                    vets$abortion,
                                    vets$title.ix,
                                    vets$prayer,
                                    vets$ssm
                                    ),
                       var_names = c(
                                     "Vouchers",
                                     "Abortion",
                                     "Title IX",
                                     "School Prayer",
                                     "Same-Sex Marriage"
                                     )
                      )

econ_table <- MakeTable(
                        vars = cbind(
                                    vets$redist,
                                    vets$spending,
                                    vets$cut_mil,
                                    vets$tariffs,
                                    vets$inflation,
                                    vets$obamacare
                                     ),
                        var_names = c(
                                      "Income Redistribution",
                                      "Cut Entitlements",
                                      "Cut Military",
                                      "Tariffs",
                                      "Inflation",
                                      "Obamacare"
                                      )
                         )

###########
# Table 1 #
###########

rbind(
      ideo_table,
      soc_table,
      econ_table
      )

###########################
# Check Balance for       #
# pre-treatment variables #
###########################

vets <- vets %>% 
          select(
                 -vouchers,
                 -abortion,
                 -title.ix,
                 -prayer,
                 -ssm,
                 -redist,
                 -spending,
                 -cut_mil,
                 -tariffs,
                 -inflation,
                 -obamacare
                 )
                        # Don't need individual questions anymore.

vets_ps <- vets[complete.cases(vets[, 1 : 12]), ]

x_mat <- vets_ps %>%
           select(
                  pserv,
                  gpa,
                  white,
                  hispanic,
                  black,
                  fam,
                  fem,
                  age,
                  vet_prop,
                  base,
                  col_prop
                  )

ps_df <- data.frame(
                    pid = vets_ps$pid,
                    vet = vets_ps$vet,
                    x_mat
                    ) %>%
           na.omit()

x_mat <- ps_df[, -c(1 : 2)]

vet_match <- matchit(
                     vet ~ 
                           pserv +
                           gpa +
                           white +
                           hispanic +
                           black +
                           fam +
                           fem +
                           age +
                           vet_prop +
                           base +
                           col_prop,
                     method = "full",
                     data = vets_ps
                     )

vet_data_matched <- match.data(vet_match)

var_names_vet <- data.frame(
                            old = c(
                                    "distance",
                                    "pserv",
                                    "gpa",
                                    "white",
                                    "hispanic",
                                    "black",
                                    "fam",
                                    "fem",
                                    "age",
                                    "vet_prop",
                                    "base",
                                    "col_prop"
                                    ),
                            new = c(
                                    "Propensity\nscores",
                                    "Parental\nservice",
                                    "GPA",
                                    "White",
                                    "Hispanic",
                                    "Black",
                                    "Family ties",
                                    "Female",
                                    "Age",
                                    "County\nveteran prop",
                                    "Military base\nin county",
                                    "County college\neducated prop"
                                    )
                            )

############
# Figure 1 #
############

love.plot(
          vet_match,
          grid         = TRUE,
          title        = "",
          abs          = TRUE,
          colors       = c("lightblue", "navyblue"),
          thresholds   = 0.05,
          size         = 4,
          var.names    = var_names_vet,
          sample.names = c(
                           "Unmatched",
                           "Matched"
                           )
          ) +
  xlab("Absolute Standardized\nMean Difference") +
  geom_vline(xintercept = 0.1) +
  theme(
        axis.text          = element_text(size = 12),
        axis.title         = element_text(size = 14),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()
        ) 

##############################
# Draftees vs. non-reluctant #
##############################

draft_ps <- vets %>%
              filter(
                     vet == 1,
                     fem == 0
                     ) %>%
                dplyr::select(
                       -pserv,
                       -gpa,
                       -fam,
                       -fem,
                       -vet,
                       -draft_reluc
                       )

draft_ps <- draft_ps[complete.cases(draft_ps[, 1 : 8]), ]

###########################
# Check Balance for       #
# pre-treatment variables #
###########################

vars_draft<-c(
              "white",
              "hispanic",
              "black",
              "ses",
              "age",
              "vet_prop",
              "base"
              )

draft_match <- matchit(
                       nonreluctant ~
                                      white +
                                      hispanic +
                                      black +
                                      ses +
                                      age +
                                      vet_prop +
                                      base,
                      method = "nearest",
                      caliper = 0.4,
                      data   = draft_ps
                      )

summary(draft_match)

draft_data_matched <- match.data(draft_match)

var_names_draft <- data.frame(
                              old = c(
                                      "distance",
                                      vars_draft
                                      ),
                              new = c(
                                      "Proponsity\nscores",
                                      "White",
                                      "Hispanic",
                                      "Black",
                                      "Parental SES",
                                      "Age",
                                      "County\nveteran prop",
                                      "Military base\nin county"
                                      )
                              )

############
# Figure 2 #
############

love.plot(
          draft_match,
          grid         = TRUE,
          title        = "",
          abs          = TRUE,
          colors       = c(
                           "lightblue", 
                           "navyblue"
                           ),
          thresholds   = 0.05,
          size         = 4,
          var.names    = var_names_draft,
          sample.names = c(
                           "Unmatched",
                           "Matched"
                           )
          ) +
  xlab("Absolute Standardized\nMean Difference") +
  geom_vline(xintercept = 0.1) +
  theme(
        axis.text  = element_text(size = 12),
        axis.title = element_text(size = 14),
        panel.grid.major.x = element_blank(),
        panel.grid.minor.x = element_blank()
        ) 


#########################
# Get estimated effects #
#########################

mods <- c(
          "pidest",
          "idest",
          "social",
          "economic"
          )

iv_vet <- "~ vet + pserv + gpa + white + hispanic + black + fam + fem + age + vet_prop + base + col_prop"

iv_draft <- "~ nonreluctant + white + hispanic + black + ses + age + vet_prop + base"

for (i in 1 : length(mods)) {
  vet_name <- paste(
                    mods[i],
                    "_vet",
                    sep = ""
                    )
  draft_name <- paste(
                      mods[i],
                      "_draft",
                      sep = ""
                      )
  vet_raw <- paste(
                   mods[i],
                   "_vet_raw",
                   sep = ""
                   )
  draft_raw <- paste(
                     mods[i],
                     "_draft_raw",
                     sep = ""
                     )
  vet_form <- paste(
                    dvs[i],
                    iv_vet,
                    sep = " "
                    ) %>%
                as.formula()

  draft_form <- paste(
                      dvs[i],
                      iv_draft,
                      sep = " "
                      ) %>%
                  as.formula()
  vet_form_raw <- paste(
                        dvs[i],
                        "~ vet",
                        sep = " "
                        ) %>%
                    as.formula()
               
  assign(
         vet_name,
         lm(
            vet_form,
            data = vet_data_matched,
            weights = weights
            )
         )
  assign(
         draft_name,
         lm(
            draft_form,
            data = draft_data_matched,
            weights = weights
            )
         )
  assign(
         vet_raw,
         lm(
            vet_form_raw,
            data = vet_data_matched
            )
         )
}

####################
# Table of results #
####################

res_pid <- list(
                 pidest_vet_raw,
                 pidest_vet,
                 pidest_draft
                 )

res_idest <- list(
                  idest_vet_raw,
                  idest_vet,
                  idest_draft
                  )

res_soc <- list(
                social_vet_raw,
                social_vet,
                social_draft
                )

res_econ <- list(
                 economic_vet_raw,
                 economic_vet,
                 economic_draft
                 )


res_table <- data.frame(
                        Category = c(
                                     "Veteran (raw)",
                                     "",
                                     "Veteran (preprocessed)",
                                     "",
                                     "True volunteer",
                                     ""
                                     ),
                        Party_ID = WeaveRes(res_pid),
                        Ideology = WeaveRes(res_idest),
                        Social   = WeaveRes(res_soc),
                        Economic = WeaveRes(res_econ)
                        )

###########
# Table 2 #
###########

print(res_table)

####################
# Plots of results #
####################

res_ideo <- list(
                 pidest_vet_raw,
                 pidest_vet,
                 pidest_draft,
                 idest_vet_raw,
                 idest_vet,
                 idest_draft
                 )

res_ind <- list(
                social_vet_raw,
                social_vet,
                social_draft,
                economic_vet_raw,
                economic_vet,
                economic_draft
                )

names_ideo <- rep(
                  c(
                    "Party ID",
                    "Ideology"
                    ),
                  each = 3
                  )

names_index <- rep(
                   c(
                     "Social\nIndex",
                     "Economic\nIndex"
                     ),
                   each = 3
                   )

group_list <- rep(
                   c(
                     "Effect of veteran\nstatus (raw)", 
                     "Effect of veteran\nstatus (pre-processed)", 
                     "Effect of voluntary\nservice (veterans only)"
                     ),
                   times = 2
                   )


############
# Figure 3 #
############

PlotMult(
         res_list    = res_ideo,
         names_res   = names_ideo,
         group_names = group_list,
         levs        = group_list[1 : 3],
         symmetric   = TRUE
         ) +
    scale_shape_manual(
                       values = c(
                                  16,
                                  15,
                                  17
                                  ),
                       name = "Model"
                       ) +
    scale_color_manual(
                       values = c(
                                  "red",
                                  "black",
                                  "lightblue"
                                  ),
                       name = "Model"
                       ) +
    theme(
          plot.title = element_text(hjust = 0.5), 
          plot.subtitle = element_text(hjust = 0.5),
          legend.position = "bottom"
          )

############
# Figure 4 #
############

PlotMult(
         res_list = res_ind,
         names_res = names_index,
         group_names = group_list,
         levs        = group_list[1 : 3],
         symmetric   = TRUE
         ) +
    scale_shape_manual(
                       values = c(
                                  16,
                                  15,
                                  17
                                  ),
                       name = "Model"
                       ) +
    scale_color_manual(
                       values = c(
                                  "red",
                                  "black",
                                  "lightblue"
                                  ),
                       name = "Model"
                       ) +
    theme(
          plot.title = element_text(hjust = 0.5), 
          plot.subtitle = element_text(hjust = 0.5),
          legend.position = "bottom"
          )

############
# APPENDIX #
############

########################
# Sensitivity analysis #
########################

res_list <- list(
                 pidest_vet_raw,
                 pidest_vet,
                 pidest_draft,
                 idest_vet_raw,
                 idest_vet,
                 idest_draft,
                 social_vet_raw,
                 social_vet,
                 social_draft,
                 economic_vet_raw,
                 economic_vet,
                 economic_draft
                 )

sens_list <- vector(
                    "list",
                    length = length(res_list)
                    )

for (i in 1 : length(sens_list)) {
  mod <- res_list[[i]]
  rel_cov <- names(coef(mod))[2]
  sens_list[[i]] <- sensemakr(
                              mod,
                              treatment = rel_cov,
                              alpha     = 0.10
                              )
}

############
# Table A1 #
############

file_name <- "ovb_tables.html"

for (i in 1 : length(sens_list)) {
  if (i == 1) {
    cat(
        ovb_minimal_reporting(
                              sens_list[[i]],
                              format  = "html",
                              verbose = FALSE
                              ),
        file  = file_name
        )
  } else {
    cat(
        ovb_minimal_reporting(
                              sens_list[[i]],
                              format  = "html",
                              verbose = FALSE
                              ),
        file   = file_name,
        append = TRUE
        )
  }
}
                        # This writes the results of the
                        # sensitivity analysis to an HTML
                        # file in the working directory.

###########################
# Regress joining on      #
# pre-treatment variables #
###########################

mod_join <- glm(
                vet ~ 
                      pserv +
                      gpa +
                      white +
                      hispanic +
                      black +
                      fam +
                      fem +
                      age +
                      vet_prop +
                      base +
                      col_prop,
                data   = vets,
                family = binomial(link = "logit")
                )

############
# Table A2 #
############

screenreg(
          mod_join,
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = "Veteran status",
          custom.coef.names  = c(
                                 "Constant",
                                 "Parental service",
                                 "GPA",
                                 "White",
                                 "Hispanic",
                                 "Black",
                                 "Family ties",
                                 "Female",
                                 "Age",
                                 "Prop. vets in county",
                                 "Base in county",
                                 "Prop. college students in county"
                                 ),
          reorder.coef       = c(
                                 2 : 12,
                                 1
                                 ),
          include.aic        = FALSE,
          include.bic        = FALSE,
          include.deviance   = FALSE,
          custom.gof.names   = c(
                                 "Log-likelihood",
                                 "Number of Observations"
                                 )
          )

################
# Full results #
################

############
# Table A3 #
############

screenreg(
          list(
               pidest_vet_raw,
               idest_vet_raw,
               social_vet_raw,
               economic_vet_raw
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Party ID",
                                 "Ideology",
                                 "Social Index",
                                 "Economic Index"
                                 ),
          custom.coef.names  = c(
                                 "Constant",
                                 "Veteran status"
                                 ),
          reorder.coef       = c(
                                 2,
                                 1
                                 ),
          include.adjrs      = FALSE,
          custom.gof.names   = c(
                                 "R$^2$",
                                 "Number of Observations"
                                 )
          )

############
# Table A4 #
############

screenreg(
          list(
               pidest_vet,
               idest_vet,
               social_vet,
               economic_vet
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Party ID",
                                 "Ideology",
                                 "Social Index",
                                 "Economic Index"
                                 ),
          custom.coef.names  = c(
                                 "Constant",
                                 "Veteran status",
                                 "Parental service",
                                 "GPA",
                                 "White",
                                 "Hispanic",
                                 "Black",
                                 "Family ties",
                                 "Female",
                                 "Age",
                                 "Prop. vets in county",
                                 "Base in county",
                                 "Prop. college students in county"
                                 ),
          reorder.coef       = c(
                                 2 : 13,
                                 1
                                 ),
          include.adjrs      = FALSE,
          custom.gof.names   = c(
                                 "R$^2$",
                                 "Number of Observations"
                                 )
          )

############
# Table A5 #
############

screenreg(
          list(
               pidest_draft,
               idest_draft,
               social_draft,
               economic_draft
               ),
          stars              = c(
                                 0.01,
                                 0.05,
                                 0.1
                                 ),
          custom.model.names = c(
                                 "Party ID",
                                 "Ideology",
                                 "Social Index",
                                 "Economic Index"
                                 ),
          custom.coef.names  = c(
                                 "Constant",
                                 "Voluntary service",
                                 "White",
                                 "Hispanic",
                                 "Black",
                                 "Socioeconomic status",
                                 "Age",
                                 "Prop. vets in county",
                                 "Base in county"
                                 ),
          reorder.coef       = c(
                                 2 : 9,
                                 1
                                 ),
          include.adjrs      = FALSE,
          custom.gof.names   = c(
                                 "R$^2$",
                                 "Number of Observations"
                                 )
          )


##########################
# Divide into officers   #
# and enlisted personnel #
##########################

vet_data_matched$officer <- vets$officer[as.numeric(rownames(vet_data_matched))]

vet_data_matched$career <- vets$career[as.numeric(rownames(vet_data_matched))]


vet_off <- vet_data_matched %>%
             filter(officer == 1 | is.na(officer)) %>%
               select(
                      -distance,
                      -weights,
                      -subclass
                      )

vet_enl <- vet_data_matched %>%
             filter(officer == 0 | is.na(officer)) %>%
               select(
                      -distance,
                      -weights,
                      -subclass
                      )

vet_mult <- vet_data_matched %>%
             filter(career == 1 | is.na(career)) %>%
               select(
                      -distance,
                      -weights,
                      -subclass
                      )

vet_sing <- vet_data_matched %>%
             filter(career == 0 | is.na(career)) %>%
               select(
                      -distance,
                      -weights,
                      -subclass
                      )

match_form <- as.formula(vet ~ pserv + gpa + white + hispanic + black + fam + fem + age + vet_prop + base + col_prop)

off_match <- matchit(
                     match_form,
                     method = "full",
                     data = vet_off
                     )

enl_match <- matchit(
                     match_form,
                     method = "full",
                     data = vet_enl
                     )

mult_match <- matchit(
                      match_form,
                      method = "full",
                      data = vet_mult
                      )

sing_match <- matchit(
                      match_form,
                      method = "full",
                      data = vet_sing
                      )

off_data_matched <- match.data(off_match)

enl_data_matched <- match.data(enl_match)

mult_data_matched <- match.data(mult_match)

sing_data_matched <- match.data(sing_match)

GetRes(
       vet_sub   = off_data_matched,
       sub_cat   = "officer"
       )

GetRes(
       vet_sub   = enl_data_matched,
       sub_cat   = "enlisted"
       )

GetRes(
       vet_sub   = mult_data_matched,
       sub_cat   = "career"
       )

GetRes(
       vet_sub   = sing_data_matched,
       sub_cat   = "single"
       )

res_disag <- list(
                  economic_vet_officer,
                  economic_vet_enlisted,
                  social_vet_officer,
                  social_vet_enlisted,
                  idest_vet_officer,
                  idest_vet_enlisted,
                  pidest_vet_officer,
                  pidest_vet_enlisted
                  )

names_disag <- rep(
                   c(
                     "Economic",
                     "Social",
                     "Ideology",
                     "Party ID"
                     ),
                   each = 2
                   )

group_disag <- rep(
                   c(
                     "Commissioned", 
                     "Non-commissioned"
                     ),
                   times = 4
                   )

res_length <- list(
                   economic_vet_single,
                   economic_vet_career,
                   social_vet_single,
                   social_vet_career,
                   idest_vet_single,
                   idest_vet_career,
                   pidest_vet_single,
                   pidest_vet_career
                   )

group_length <- rep(
                    c(
                      "0-6 years",
                      "7+ years"
                      ),
                    times = 4
                    )

off_enl <- PlotMult(
                     res_list    = res_disag,
                     names_res   = names_disag,
                     group_names = group_disag,
                     levs        = group_disag[1 : 2],
                     symmetric   = TRUE
                     ) +
                scale_shape_manual(
                                   values = c(
                                              16,
                                              15
                                              ),
                                   name = "Model"
                                   ) +
                scale_color_manual(
                                   values = c(
                                              "navyblue",
                                              "lightblue"
                                              ),
                                   name = "Model"
                                   ) +
                # labs(
                #      title = "Estimated effect", 
                #      subtitle = paste0(
                #                        "(",
                #                        group_names[i],
                #                        ")"
                #                        )
                #      ) + 
                xlab("Estimated effect of veteran status") +
                ylab("Dependent variable") +
                theme(
                      plot.title = element_text(hjust = 0.5), 
                      plot.subtitle = element_text(hjust = 0.5),
                      legend.position = "bottom"
                      )

mult_sing <- PlotMult(
                      res_list    = res_length,
                      names_res   = names_disag,
                      group_names = group_length,
                      levs        = group_length[1 : 2],
                      symmetric   = TRUE
                      ) +
                 scale_shape_manual(
                                    values = c(
                                               16,
                                               15
                                               ),
                                    name = "Model"
                                    ) +
                 scale_color_manual(
                                    values = c(
                                               "navyblue",
                                               "lightblue"
                                               ),
                                    name = "Model"
                                    ) +
                 # labs(
                 #      title = "Estimated effect", 
                 #      subtitle = paste0(
                 #                        "(",
                 #                        group_names[i],
                 #                        ")"
                 #                        )
                 #      ) + 
                 xlab("Estimated effect of veteran status") +
                 ylab("Dependent variable") +
                 theme(
                       plot.title = element_text(hjust = 0.5), 
                       plot.subtitle = element_text(hjust = 0.5),
                       legend.position = "bottom"
                       )

#############
# Figure A1 #
#############

off_enl

#############
# Figure A2 #
#############

mult_sing
