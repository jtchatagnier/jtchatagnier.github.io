########################################
# These programs are necessary for the #
# replication file for "Teaching the   #
# Enemy: The Empirical Implications of #
# Barganing Under Observation          #
#                                      #
# Created 2013 by: J. Tyson Chatagnier #
#                                      #
########################################

#########################
# Function to calculate #
# number of days.       #
#########################

days.calc <- function(yr, mo, day) {
    yrs.days <- ((yr - 1) * 365) + ifelse(mo > 2, trunc(yr / 4),
                trunc((yr - 1) / 4))
    if (mo == 1) {
        mos.days <- 0
    } else if (mo == 2) {
        mos.days <- 31
    } else if (mo == 3) {
        mos.days <- 59
    } else if (mo == 4) {
        mos.days <- 90
    } else if (mo == 5) {
        mos.days <- 120
    } else if (mo == 6) {
        mos.days <- 151
    } else if (mo == 7) {
        mos.days <- 181
    } else if (mo == 8) {
        mos.days <- 212
    } else if (mo == 9) {
        mos.days <- 243
    } else if (mo == 10) {
        mos.days <- 273
    } else if (mo == 11) {
        mos.days <- 304
    } else {
        mos.days <- 334
    }
    days <- ifelse(day == -9, 0, day)
    return(yrs.days + mos.days + days)
}

##############################
# Function to get the effect #
# of an interaction for a    #
# non-proportional hazard    #
##############################

cox.int <- function(model, main.var, int.var, nph.var, num.int,
                    num.out, daily = TRUE) {
    nphvals <- matrix(c(model$coef[main.var] + num.int * model$coef[int.var],
                        model$coef[nph.var]), ncol = 2, byrow = T)
    var.mod <- diag(vcov(model))
    se.int <- sqrt(var.mod[main.var] + num.int^2 * var.mod[int.var] +
                    2 * num.int * vcov(model)[main.var, int.var])
    se.nph <- c(se.int, sqrt(var.mod)[nph.var])
    nph.lo <- nphvals - (1.96 * se.nph)
    nph.hi <- nphvals + (1.96 * se.nph)
    length.time <- seq(from = 1, to = num.out)
    if (daily) {
        lo.out <- out.cox.mult(nph.mat = nph.lo, n = num.out) / 30
        est.out <- out.cox.mult(nph.mat = nphvals, n = num.out) / 30
        hi.out <- out.cox.mult(nph.mat = nph.hi, n = num.out) / 30
                            # The function gives us the effect of a month by
                            # default, due to the recoding. If we want to get
                            # daily effects, we need to divide by 30.
    } else {
        lo.out <- out.cox.mult(nph.mat = nph.lo, n = num.out)
        est.out <- out.cox.mult(nph.mat = nphvals, n = num.out)
        hi.out <- out.cox.mult(nph.mat = nph.hi, n = num.out)
    }
    return(list(lo = lo.out, est = est.out, hi = hi.out,se = se.nph))
}

##################
# Plot Functions #
##################

out.cox.mult <- function(ph.vec = NULL, nph.mat = NULL, n = 365){
                            # Takes a vector and a matrix as an argument.
                            # The vector gives any proportional hazard
                            # coefficients we want to plot. Column 1 of the
                            # matrix is the NPH coefficients by themselves,
                            # and column 2 is the vector of interactions.
    x.time <- log(seq(1 : n))
    change.ph <- function(x) {
        vals.vec <- 100 * (exp(x) - 1)
        return(matrix(rep(vals.vec, each = length(x.time)),
                        nrow = length(x), byrow = T))
    }
    change.nph <- function(nph.vec) {
        vals.vec <- 100 * (exp(nph.vec[1] + (nph.vec[2] * x.time)) - 1)
        return(vals.vec)
    }
    if (!is.null(ph.vec)) {
        vals.ph <- change.ph(ph.vec)
    } else {
        vals.ph <- NULL
    }
    if (!is.null(nph.mat)) {
        vals.nph <- t(apply(nph.mat, 1, change.nph))
    } else {
        vals.nph <- NULL
    }
    if (is.null(ph.vec)) {
        return(vals.nph)
    } else {
        return(list(vals.ph = vals.ph, vals.nph = vals.nph))
    }
}

plot.cox.mult <- function(ph.vec = NULL, nph.mat = NULL, n = 365,
                            plot.title = NULL,
                            y.lim = c(min(vals.ph, vals.nph),
                                    max(vals.ph, vals.nph)), daily = TRUE) {
                            # Takes a vector and a matrix as an argument.
                            # The vector gives any proportional hazard
                            # coefficients we want to plot. Column 1 of the
                            # matrix is the NPH coefficients by themselves,
                            # and column 2 is the vector of interactions.
    x.time <- log(seq(1 : n))
    change.ph <- function(x) {
        vals.vec <- 100 * (exp(x) - 1)
        return(matrix(rep(vals.vec, each = length(x.time)),
                nrow = length(x), byrow = T))
    }
    change.nph <- function(nph.vec) {
        vals.vec <- 100 * (exp(nph.vec[1] + (nph.vec[2] * x.time)) - 1)
        return(vals.vec)
    }
    if (!is.null(ph.vec)) {
        vals.ph <- change.ph(ph.vec)
    } else {
        vals.ph <- NULL
    }
    if (!is.null(nph.mat)) {
        vals.nph <- t(apply(nph.mat, 1, change.nph))
    } else {
        vals.nph <- NULL
    }
    if (is.null(ph.vec)) {
        if (nrow(nph.mat) > 1) {
            plot(exp(x.time), vals.nph[1,] / 30, type = "l", ylim = y.lim,
                xlab = "Days Since Last Conflict",
                ylab = "Percent Change in Hazard", main = plot.title,
                lwd = 2, lty = 1)
            for (i in 2 : nrow(vals.nph)) {
                lines(vals.nph[i,] / 30, lwd = 2, lty = i)
            }
        } else {
            plot(exp(x.time), vals.nph[1,] / 30, type = "l", ylim = y.lim,
                xlab = "Days Since Last Conflict",
                ylab = "Percent Change in Hazard", main = plot.title,
                lwd = 2, lty = 1)
        }
    } else {
        if (length(ph.vec) > 1) {
            plot(exp(x.time), vals.ph[1,] / 30, type = "l", ylim = y.lim,
                xlab = "Days Since Last Conflict",
                ylab = "Percent Change in Hazard", main = plot.title,
                lwd = 2, lty = 2)
            for (i in 2 : nrow(vals.ph)) {
                lines(vals.ph[i,] / 30, lwd = 2, lty = (i + 1))
            }
            for (i in 1 : nrow(vals.nph)) {
                lines(vals.nph[i,] / 30, lwd = 2, lty = 1,
                    col = rainbow(nrow(vals.nph)))
            }
        } else {
            plot(exp(x.time), vals.ph[1,] / 30, type = "l", ylim = y.lim,
                xlab = "Days Since Last Conflict",
                ylab = "Percent Change in Hazard",
                main = plot.title, lwd = 2, lty = 2)
            for (i in 1 : nrow(vals.nph)) {
                lines(vals.nph[i,] / 30, lwd = 2, lty = 1,
                    col = rainbow(nrow(vals.nph)))
            }
        }
    }
}
