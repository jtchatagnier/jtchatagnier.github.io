###############################################
# Code to replicate the analysis for:         #
#                                             #
# "The internationalization of production and #
# compliance in WTO disputes"                 #
#                                             #
# Aydin Yildirim, J. Tyson Chatagnier,        #
# Arlo Poletti, and Dirk De Bievre            #
#                                             #
# Forthcoming in the Review of International  #
# Organizations                               #
#                                             #
# File created 10 March 2017                  #
###############################################

rm(list = ls())

library(ggplot2)
library(survival)
library(texreg)
library(gridExtra)
library(reshape)

# setwd("")
                        # Uncomment and add path to change working directory

source("ipc_auxiliary_functions.r")
                        # Auxiliary file to be sourced

set.seed(2016)
                        # Set seed for replication purposes

#################
# Read in data. #
#################

wiod <- read.csv("wto_compliance_wiod.csv")

list.names <- c("id",
                "defendant",
                "name",
                "date",
                "litigant",
                "industry",
                "dev.lit",
                "dev.def",
                "compliance",
                "complytime.new",
                "complytime",
                "complytime.days",
                "polity.def",
                "polity.lit",
                "ag",
                "eu",
                "usa",
                "def.exp.share",
                "complex",
                "gdp.def",
                "gdp.comp",
                "lngdp.def",
                "lngdp.comp",
                "power.gdp", 
                "sector.output",
                "sec.cons",
                "imp.dep",
                "sec.val",
                "sec.val.per",
                "fdi.out",
                "fdi.in.comp",
                "fdi.share",
                "veto"
                )

colnames(wiod) <- list.names

tiva <- read.csv("wto_compliance_tiva.csv")

list.names <- c("id",
                "defendant",
                "name",
                "date",
                "litigant",
                "industry",
                "dev.lit",
                "dev.def",
                "compliance",
                "complytime.new",
                "complytime",
                "complytime.days",
                "polity.def",
                "polity.lit",
                "ag",
                "eu",
                "usa",
                "def.exp.share",
                "complex",
                "gdp.def",
                "gdp.comp",
                "lngdp.def",
                "lngdp.comp",
                "power.gdp", 
                "sector.output",
                "sec.int",
                "int.imp",
                "sec.imp",
                "imp.dep",
                "foreign.exp",
                "sec.val",
                "sec.val.per",
                "fdi.out",
                "fdi.in.comp",
                "fdi.share",
                "veto"
                )

colnames(tiva) <- list.names

##############################
# Make necessary adjustments #
# to the two data sets       #
##############################

wiod$dem.lo <- ifelse(wiod$polity.def > wiod$polity.lit,
                      wiod$polity.lit,
                      wiod$polity.def
                      )
                        # Create a variable for dyadic democracy

wiod$dem.hi <- ifelse(wiod$polity.def < wiod$polity.lit,
                      wiod$polity.lit,
                      wiod$polity.def
                      )
                        # Create a variable for higher democracy level

wiod$year <- as.character(wiod$date)

wiod$year[1 : 85] <- substr(wiod$year[1 : 85], 
                            1 , 
                            4
                            )

wiod$year[86 : length(wiod$year)] <- substrRight(wiod$year[86 : length(wiod$year)], 
                                                2
                                                )

wiod$year <- ifelse(as.numeric(wiod$year) < 100,
                    ifelse(as.numeric(wiod$year) > 50,
                           paste("19",
                                 wiod$year,
                                 sep = ""
                                 ),
                           paste("20",
                                 wiod$year,
                                 sep = ""
                                 )
                           ),
                    wiod$year
                    )

wiod$year <- as.numeric(wiod$year)
                        # Get the year for each of the observations.
                        # NOTE: this hard codes the observation numbers, based
                        # on present spreadsheet. If data are updated, THIS
                        # SECTION OF CODE MUST BE CHANGED AS WELL.

wiod$year.fac <- factor(ifelse(wiod$year == 2004,
                               2005,
                               wiod$year
                               )
                        )
                        # Create a factor variable for the year. Group 
                        # 2004 with 2005 because it gives us problems:
                        # there are no uncensored, complete observations in 
                        # 2004. Grouping it with 2005, rather than 2003,
                        # because the expiration of the Peace Clause matters.

wiod$lnsec.val <- log(as.numeric(wiod$sec.val))
                        # Log this because it's so much different from the
                        # rest of the variables in terms of scale

wiod$complytime.new <- as.numeric(wiod$complytime.new)
                        # Turn this into a numeric, rather than factor variable.

wiod[wiod == -99] <- NA
tiva[tiva == -99] <- NA
                        # Turn -99s into NAs.

tiva$dem.lo <- ifelse(tiva$polity.def > tiva$polity.lit,
                      tiva$polity.lit,
                      tiva$polity.def
                      )
                        # Create a variable for dyadic democracy
tiva$dem.hi <- ifelse(tiva$polity.def < tiva$polity.lit,
                      tiva$polity.lit,
                      tiva$polity.def
                      )
                        # Create a variable for higher democracy level

tiva$year <- as.character(tiva$date)
tiva$year <- substr(tiva$year, 
                    1 , 
                    4
                    )
tiva$year <- as.numeric(tiva$year)

tiva$year.fac <- factor(ifelse(tiva$year == 2004,
                               2005,
                               tiva$year
                               )
                        )
                        # Create a factor variable for the year. Group 
                        # 2004 with 2005 because it gives us problems:
                        # there are no uncensored, complete observations in 
                        # 2004. Grouping it with 2005, rather than 2003,
                        # because the expiration of the Peace Clause matters.

tiva$lnsec.val <- log(tiva$sec.val)
                        # Log this because it's so much different from the
                        # rest of the variables in terms of scale

##########################
# Descriptive Statistics #
##########################

wiod$sector <- ifelse(wiod$industry == "Food Beverages and Tobacco",
                      "Food and\nBeverages",
                      ifelse(wiod$industry == "Textiles and Textile products",
                             "Textiles",
                             ifelse(wiod$industry == "Basic Metals and Fabricated Metal",
                                    "Basic Metals and\nFabricated Metals",
                                    ifelse(wiod$industry == "Agriculture",
                                           "Agriculture",
                                           ifelse(wiod$industry == "Transport Equipment",
                                                  "Transport\nEquipment",
                                                  ifelse(wiod$industry == "Electrical and Optical Equipment",
                                                         "Electrical and\nOptical Equipment",
                                                         ifelse(wiod$industry == "-99",
                                                                NA,
                                                                "Other"
                                                                )
                                                         )
                                                  )
                                           )
                                    )
                             )
                      )

sector.vals <- factor(wiod$sector,
                      levels = names(sort(table(wiod$sector), 
                                  decreasing = TRUE
                                  )
                             )
                      )

sec.avg <- rbind(by(wiod$imp.dep, sector.vals, mean, na.rm = T))

sec.avg <- sec.avg[, colnames(sec.avg)]

names.avg <- factor(names(sec.avg),
                    levels = names(sort(table(wiod$sector), 
                                        decreasing = TRUE
                                        )
                                   )
                    )


comp.avg <- rbind(by(wiod$complytime, sector.vals, mean, na.rm = T))

comp.avg <- comp.avg[, colnames(comp.avg)]


############
# Figure 1 #
############

group.df <- data.frame(Name        = names.avg,
                       Frequency   = as.numeric(table(sector.vals)),
                       Compliance  = as.numeric(comp.avg),
                       Integration = as.numeric(sec.avg)
                       )

group.df <- group.df[group.df$Name != "Other", ]
                        # Focus on the six main categories, and remove
                        # everything else.

names(group.df)[2] <- "Frequency\n(% of Disputes)\n"
names(group.df)[3] <- "Avg. Time to\nCompliance\n(Months)"
names(group.df)[4] <- "\nImport Dependence\n(% of Total Output)"

group.df <- melt(group.df,
                 id.vars = "Name"
                 )

colnames(group.df) <- c("Name",
                        "Variable",
                        "value"
                        )

pdf("sector_values.pdf",
    width  = 9,
    height = 6
    )
  ggplot(data = group.df,
         aes(x = Name,
             y = value
             )
         ) +
    geom_bar(aes(fill     = Variable),
                 position = "dodge",
                 stat     = "identity"
                 ) +
    xlab("Sector") +
    ylab("") +
    scale_fill_grey() +
    theme_bw()
dev.off()

###########
# Table 1 #
###########

vars <- with(wiod,
             cbind(complytime, imp.dep, polity.def, def.exp.share, 
                   lnsec.val, veto, fdi.share
                   )
             )

min.vars <- apply(vars,
                  2,
                  min,
                  na.rm = T
                  )

max.vars <- apply(vars,
                  2,
                  max,
                  na.rm = T
                  )

mean.vars <- apply(vars,
                   2,
                   mean,
                   na.rm = T
                   )

sd.vars <- apply(vars,
                 2,
                 sd,
                 na.rm = T
                 )

df.vars <- data.frame(Minimum = round(min.vars, 
                                      digits = 2
                                      ),
                      Maximum = round(max.vars, 
                                      digits = 2
                                      ),
                      Mean    = round(mean.vars, 
                                      digits = 2
                                      ),
                      SD      = round(sd.vars, 
                                      digits = 2
                                      )
                      )

rownames(df.vars) <- c("Months to compliance",
                       "GVC integration",
                       "Defendant polity score",
                       "Defendant export dependence",
                       "Sector value added",
                       "Veto players",
                       "FDI share"
                       )

df.vars
                        # This reproduces Table 1 in the paper

############
# Analysis #
############

##################################
# Duration analysis of the data. #
##################################

wiod$comply.surv <- Surv(wiod$complytime, 
                         wiod$compliance
                         )
tiva$comply.surv <- Surv(tiva$complytime, 
                         tiva$compliance
                         )
                        # The complytime variable gives us the time in
                        # months that it took the target to comply.
                        # The compliance variable tells us whether
                        # compliance has occurred, so it's a zero if
                        # the trade dispute is still ongoing.

mod.base <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                complex + lnsec.val + veto + fdi.share +
                                eu + usa,
                  data = wiod,
                  x    = TRUE
                  )

mod.dep <- coxph(comply.surv ~ polity.def + def.exp.share + 
                               complex + lnsec.val + veto + fdi.share + 
                               eu + usa + imp.dep,
                  data = wiod,
                  x    = TRUE
                  )  

mod.time <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                complex + lnsec.val + veto + fdi.share + 
                                eu + usa + imp.dep + year.fac,
                  data = wiod,
                  x    = TRUE
                  )  

mod.imp <- coxph(comply.surv ~ polity.def + def.exp.share + 
                               complex + lnsec.val + veto + fdi.share + 
                               eu + usa + imp.dep + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

mod.int <- coxph(comply.surv ~ polity.def + def.exp.share + 
                               complex + lnsec.val + veto + fdi.share + 
                               eu + usa + int.imp + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

mod.exp <- coxph(comply.surv ~ polity.def + def.exp.share + 
                               complex + lnsec.val + veto + fdi.share + 
                               eu + usa + foreign.exp + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

##############################
# Tests for non-proportional #
# hazards for each model     #
##############################

nph.base <- cox.zph(mod.base, 
                    transform = sqrt
                    )

nph.dep <- cox.zph(mod.dep, 
                   transform = sqrt
                   )

nph.time <- cox.zph(mod.time, 
                    transform = sqrt
                    )

nph.imp <- cox.zph(mod.imp, 
                   transform = sqrt
                   )

nph.int <- cox.zph(mod.int, 
                   transform = sqrt
                   )

nph.exp <- cox.zph(mod.exp, 
                   transform = sqrt
                   )

nph.base

nph.dep

nph.time

nph.imp

nph.int

nph.exp

###########
# Table 2 #
###########

write(htmlreg(list(mod.base,
                   mod.dep,
                   mod.time,
                   mod.imp,
                   mod.int,
                   mod.exp
                   ),
              stars              = c(0.01, 
                                     0.05, 
                                     0.10
                                     ),
              omit.coef          = "year.fac",
              custom.model.names = c("Baseline",
                                     "Integration Included",
                                     "Time Included",
                                     "Import Dep.",
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     ),
              custom.coef.names  = c("Defendant Democracy",
                                     "Def. Export Dependence",
                                     "Issue Complexity",
                                     "Sectoral Value Added",
                                     "Veto Players",
                                     "Share of FDI Stocks",
                                     "EU Defendant",
                                     "US Defendant",
                                     "Import Dependence",
                                     names(coef(mod.time))[10 : 23],
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     )
        ),
        file = "duration_model_results.doc"
)
                        # This outputs the six models as HTML, and
                        # writes them to a .doc file.

#################################
# Substantive results:          #
#                               #
# Plot the expected duration    #
# across its theoretical range, #
# averaging over the data.      #
#################################

min.imp <- min(wiod$imp.dep,
               na.rm = TRUE
               )

max.imp <- max(wiod$imp.dep,
               na.rm = TRUE
               )

imp.vals <- seq(from       = min.imp,
                to         = max.imp,
                length.out = 1000
                )

mat.pred <- matrix(nrow = length(imp.vals),
                   ncol = 3
                   )

for (i in 1 : length(imp.vals)) {
  boot.vals <- BootDur(mod      = mod.time,
                       var      = "imp.dep",
                       vals     = imp.vals[i],
                       se       = TRUE
                       )
  mat.pred[i, ] <- c(boot.vals$point, 
                     boot.vals$point - boot.vals$se, 
                     boot.vals$point + boot.vals$se
                     )
  cat("Iteration", i, "of", length(imp.vals), "complete.\n")
}

dur.df <- data.frame(Duration = mat.pred[, 1],
                     Change   = imp.vals,
                     Lo       = mat.pred[, 2],
                     Hi       = mat.pred[, 3]
                     )

############
# Figure 2 #
############

pdf("avg_expected_duration_wiod.pdf")
  ggplot(data = dur.df,
         aes(x = Change,
             y = Duration
             )
         ) +
    geom_ribbon(aes(ymin = Lo,
                    ymax = Hi
                    ),
                alpha  = 0.3,
                colour = "darkgray"
                ) +
    geom_line(size   = 1.10,
              colour = "navyblue"
              ) +
    xlab("Level of Import Dependence") +
    ylab("Expected Time Until Compliance (in Months)") +
    theme_bw()
dev.off()

###############################
# Plot expected durations for #
# specific cases in the data. #
###############################

wiod.nona <- wiod[complete.cases(vars), ]
                        # The vars object contains all of the non-dummy
                        # variables of interest for our analysis. We can
                        # use this to remove the relevant NA rows from our
                        # larger data set

cases <- c(23, 37)

case.names <- c("Biotech Marketing",
                "Gasoline Standards"
                )
                        # Need to change this if the cases change

titles <- paste(wiod.nona$litigant[cases],
                "-",
                wiod.nona$defendant[cases],
                " ",
                case.names,
                " (",
                wiod.nona$year[cases],
                ")",
                sep = ""
                )

plot.lo <- PlotDur(mod  = mod.time,
                   vec  = mod.time$x[23, ],
                   var  = "imp.dep",
                   vals = seq(0, 50),
                   boot = FALSE
                   )

plot.hi <- PlotDur(mod  = mod.time,
                   vec  = mod.time$x[37, ],
                   var  = "imp.dep",
                   vals = seq(0, 50),
                   boot = FALSE
                   )

p.lo <- plot.lo +
          geom_point(aes(x = wiod.nona$imp.dep[23],
                         y = wiod.nona$complytime[23]
                         ),
                     size   = 5,
                     colour = "red"
                     ) +
          xlab("Import Dependence") +
          ylab("Expected Time Until Compliance (in Months)") +
          ggtitle(titles[1]) +
          theme_bw()

p.hi <- plot.hi +
          geom_point(aes(x = wiod.nona$imp.dep[37],
                         y = wiod.nona$complytime[37]
                         ),
                     size   = 5,
                     colour = "red"
                     ) +
          xlab("Import Dependence") +
          ylab("Expected Time Until Compliance (in Months)") +
          ggtitle(titles[2]) +
          theme_bw()

############
# Figure 3 #
############

pdf("two_cases_wiod.pdf",
    width  = 16,
    height = 8
    )
  grid.arrange(p.lo, 
               p.hi, 
               ncol = 2
               )
dev.off()
