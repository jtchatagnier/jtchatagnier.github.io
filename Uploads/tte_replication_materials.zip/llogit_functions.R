########################################
# These programs are necessary for the #
# replication file for "Teaching the   #
# Enemy: The Empirical Implications of #
# Barganing Under Observation          #
#                                      #
# Created 2013 by: J. Tyson Chatagnier #
#                                      #
########################################


##############################################################
# Functions for the hybrid product kernel, using Triangular: #
# Here, q1 is the number of continuous variables,            #
# q2 is the number of ordered, and q3 is the number          #
# of unordered (or binary).                                  #
##############################################################

kernel.fn <- function(u) {
    (1 - abs(u)) * (abs(u) <= 1)
}
                            # This is the Triangular kernel function.

cont.fn <- function(q1, X, x, h, X.c = NULL){
    if (is.null(X.c)) {
        X.c <- X
    } else if (!is.matrix(X.c)) {
        X.c <- t(as.matrix(X.c))
    }
                            # Allows the user to input a matrix of values.
    if (q1 > 1) {
        diff.mat <- sweep(X[, 1 : (q1)], 2, X.c[x, 1 : (q1)])
                            # This means that columns 1 through q1 are
                            # continuous regressors.
                            # This part of the function subtracts the
                            # profile of values for observation x from the
                            # profile of values for each observation.
        kernel.wt <- kernel.fn(diff.mat / h)
                            # This applies the kernel function to the
                            # difference over the bandwidth, h.
        if (any(kernel.wt[, 2] != 0)) {
            prods <- rowProds(kernel.wt)
        } else {
            prods <- rep(0, times = nrow(kernel.wt))
        }
                            # This takes the product across all q1 variables
                            # for each observation
        prods <- ifelse(is.na(prods), 0, prods)
                            # Sometimes rowProds has issues with zeroes in
                            # certain columns, but it only occurs when the
                            # product would be zero. This fixes it.
        return(prods)
    } else if (q1 == 1) {
                            # This does the same thing, but is just redone
                            # for when there is only one continuous regressor.
        diff.mat <- X[, 1] - X.c[x, 1]
        kernel.wt <- kernel.fn(diff.mat / h)
        return(kernel.wt)
    } else {
                            # If there are no continuous regressors, we just
                            # multiply by one.
        return(1)
    }
}

ord.fn <- function(q1, q2, X, x, delta, X.c = NULL){
    if (is.null(X.c)) {
        X.c <- X
    } else if (!is.matrix(X.c)) {
        X.c <- t(as.matrix(X.c))
    }
    if (q2 > 1) {
        diff.mat <- sweep(X[,(q1 + 1) : (q1 + q2)], 2,
                            X.c[x, (q1 + 1) : (q1 + q2)])
                            # This means that columns q1+2 through q1+q2+1
                            # are ordered.
                            # This subtracts the profiles again.
        kernel.wt <- delta^abs(diff.mat)
                            # The weighting function here is the bandwidth,
                            # delta, raised to the absolute value of the
                            # difference.
        prods <- rowProds(kernel.wt)
                            # This takes the product across all q2 ordered
                            # regressors.
        prods <- ifelse(is.na(prods), 0, prods)
                            # Sometimes rowProds has issues with zeroes in
                            # certain columns, but it only occurs when the
                            # product would be zero. This fixes it.
        return(prods)
    } else if (q2 == 1) {
                            # This does the same thing, but is for the case
                            # of only one ordered regressor.
        diff.mat <- X[,q1 + q2] - X.c[x, q1 + q2]
        kernel.wt <- delta^abs(diff.mat)
        return(kernel.wt)
    } else {
                            # If we have none, then we multiply by one.
        return(1)
    }
}

unord.fn <- function(q3, X, x, lambda, X.c = NULL){
    if (is.null(X.c)) {
        X.c <- X
    } else if (!is.matrix(X.c)) {
        X.c <- t(as.matrix(X.c))
    }
    if (q3 > 1) {
        kernel.wt <- lambda^sweep(X[, (ncol(X) - q3 + 1) : ncol(X)], 2,
                                    X.c[x, (length(X.c[x, ]) - q3 + 1) :
                                    length(X.c[x, ])], FUN = '!=')
                            # The last q3 columns (q1 + q2 + 2 through
                            # q1 + q2 + q3 + 1) are unordered.
                            # The exponent will return TRUE/FALSE for each
                            # observation, where TRUE means that the two are
                            # not the same.
                            # If they are the same, this will be 1; if they
                            # are different, it will be lambda.
        prods <- rowProds(kernel.wt)
                            # This takes the product across all 3 unordered
                            # variables.
        prods <- ifelse(is.na(prods), 0, prods)
                            # Sometimes rowProds has issues with zeroes in
                            # certain columns, but it only occurs when the
                            # product would be zero. This fixes it.
        return(prods)
    } else if (q3 == 1) {
                            # This is what we do if there is only one
                            # (relevant here).
        kernel.wt <- lambda^(X[, ncol(X)] != X.c[x, ][length(X.c[x, ])])
                            # This compares the last regressor for each
                            # observation to the last regressor for the
                            # observation in question.
        return(kernel.wt)
    } else {
                            # If we have no unordered regressors, we multiply
                            # by one.
        return(1)
    }
}

#########################
# Function to calculate #
# bandwidth parameters. #
#########################

bandwidth.fn <- function(par, X, Y, q1, q2, q3){
    h <- par[1]
    delta <- par[2]
    lambda <- par[3]
    X.const <- cbind(1,X)
    mat.b <- foreach(i = c(1 : nrow(X)), .combine = "rbind",
                    .packages = "matrixStats",
                    .export = c("cont.fn", "kernel.fn", "ord.fn",
                                "unord.fn")) %dopar% {
                        kernel.wt <- (cont.fn(q1, X, i, h) *
                        ord.fn(q1, q2, X, i, delta) *
                        unord.fn(q3, X, i, lambda))[-i]
                        glm.fit(X.const[-i, ], Y[-i], weights = kernel.wt,
                        family = binomial(link = "logit"))$coef
                    }
                            # Estimate leave-one-out fitted likelihood for
                            # each observation.
                            # Uses foreach to allow for parallel computing.
    xb <- rowSums(X.const * mat.b)
                            # This performs the same operation as applying
                            # '%*%' to each row.
    lnp0 <- log(1 / (1 + exp(xb)))
    lnp1 <- log(1 / (1 + exp(-xb)))
    lnp0 <- ifelse(lnp0 == -Inf, -xb, lnp0)
    lnp1 <- ifelse(lnp1 == -Inf, xb, lnp1)
                            # These two lines eliminate the problem of machine
                            # zero and rounding error.
                            # The log of (1 + exp(x)) approaches x as x goes
                            # to infinity, so at the values where this is a
                            # problem, the change will be negligible, and
                            # should be superior to what R is trying to do.
    lik <- Y * lnp1 + (1 - Y) * lnp0
    log.lik <- sum(lik, na.rm = TRUE)
                            # Shouldn't have any NAs, but just in case.
    log.lik <- ifelse(any(is.na(lik)), log.lik * 10000, log.lik)
                            # Penalize log-likelihoods if we have NAs.
    cat("\n", "Parameters: ", "h =", h, ", delta =", delta, ",
        lambda =", lambda, "\n", "Log-Likelihood: ", log.lik, "\n")
    return(log.lik)
}

###################################################################
# Function to estimate bandwidth parameters via cross-validation. #
# This is general enough to use a matrix of start values so that  #
# we can try to find a global---rather than local---maximum.      #
#                                                                 #
# NOTE: This process is very resource intensive, and should       #
# ideally be written to use the doSNOW package and run on a large #
# multinode cluster. As written, this allows replication on a PC. #
#                                                                 #
###################################################################

cv.parallel <- function(nwork, stval.mat, X, Y, q1, q2, q3) {
                            # Estimating 3 parameters, so stval.mat should be
                            # a 3 column matrix
    require(doSMP)
    capture.output(rmSessions(all = T),file = 'NUL')
    workers <- startWorkers(nwork)
    registerDoSMP(workers)
                            # Telling R to use nwork cores on the computer.
                            # The doSMP package is used for multicore
                            # computing on a Windows PC. Should use doSNOW for
                            # a cluster, or doMC for Mac or Linux systems.
    params.mat <- matrix(nrow = nrow(stval.mat), ncol = ncol(stval.mat))
    llik.vec <- rep(NA, times = nrow(stval.mat))
    for (i in 1 : nrow(stval.mat)) {
        stval.bw <- stval.mat[i, ]
                            # Using start values from the matrix
        bw.est <- optim(stval.bw, bandwidth.fn, hessian = F,
                        method = "L-BFGS-B", lower = c(4, 0.0001, 0.0001),
                        upper = c(Inf, 1, 1),
                        control = list(fnscale = -1, trace = 1, REPORT = 1,
                                        maxit = 2000, factr = 1e-300),
                        X = X, Y = Y, q1 = q1, q2 = q2, q3 = q3)
                            # The coefficients associated with this are the
                            # optimal bandwidth parameters.
                            # Setting h>=4 and the other parameters >=0.0001
                            # here because there will be problems with zeroes
                            # if they become too small. This can be adjusted.
        params.mat[i,] <- bw.est$par
        llik.vec[i] <- bw.est$value
    }
    stopWorkers(workers)
    return(list(par = params.mat, llik = llik.vec))
}

###############################
# Estimate parameters and     #
# likelihood, given bandwidth #
###############################

llog.calc <- function(Y, X, bw.vec, q1, q2, q3) {
    n <- length(Y)
    k <- ncol(X)

    coef.mat <- matrix(nrow = n, ncol = k + 1)
    lik.vec <- vector(length = n)

    for(i in 1 : n){
            kernel.wt <- (cont.fn(q1, X, i, bw.vec[1]) *
                            ord.fn(q1, q2, X, i, bw.vec[2]) *
                            unord.fn(q3, X, i, bw.vec[3]))
            mod.est <- glm(Y ~ X, weights = kernel.wt,
                            family = binomial(link = "logit"))
            coef.mat[i,] <- mod.est$coef
            lik.vec[i] <- logLik(mod.est)
        }
                                # For some reason, this doesn't seem to work
                                # with foreach, so I use a regular for loop.

    return(list(coef = coef.mat, lik = lik.vec))
}

##################################
# Functions for model comparison #
##################################

betas.out <- function(Y, X, bw, q1, q2, q3, nwork = 4, profiles = NULL) {
                                # This function gets the betas from a local
                                # logit analysis, needed for plotting ROC
                                # curves and conducting Vuong tests.
    require(doSMP)
    capture.output(rmSessions(all = T),file = 'NUL')
    workers <- startWorkers(nwork)
    registerDoSMP(workers)
    if (is.null(profiles)) {
        mat.out <- foreach(i = c(1 : length(Y)), .combine = "rbind",
                            .packages = "matrixStats",
                            .export = c("cont.fn", "kernel.fn", "ord.fn",
                                        "unord.fn")) %dopar% {
                                kernel.wt <- (cont.fn(q1, X, i, bw[1]) *
                                                ord.fn(q1, q2, X, i, bw[2]) *
                                                unord.fn(q3, X, i, bw[3]))
                                glm.fit(cbind(1, X), Y, weights = kernel.wt,
                                        family = binomial(link = "logit"))$coef
                            }
    } else {
        mat.out <- foreach(i = c(1 : nrow(profiles)), .combine = "rbind",
                            .packages = "matrixStats",
                            .export = c("cont.fn", "kernel.fn", "ord.fn",
                                        "unord.fn")) %dopar% {
                                kernel.wt <- (cont.fn(q1, X, i, bw[1], 
                                                        X.c = profiles) *
                                                ord.fn(q1, q2, X, i, bw[2],
                                                        X.c = profiles) *
                                                    unord.fn(q3, X, i, bw[3],
                                                        X.c = profiles))
                                glm.fit(cbind(1, X), Y, weights = kernel.wt,
                                        family = binomial(link = "logit"))$coef
                            }
    }
    stopWorkers(workers)
    return(mat.out)
}

lik.fn <- function(y, p) {
    y * p + (1 - y) * (1 - p)
}

vuong.test <- function(L1, L2, K1, K2, n, alpha = 0.05) {
                            # L1 and L2 are vectors of individual
                            # log-likelihoods.
                            # K1 and K2 are respective numbers of parameters.
                            # n is the number of observations.
    df.corr <- K1 / 2 * log(n) - K2 / 2 * log(n)
    numerator <- (sum(L1) - sum(L2)) - df.corr
    term.1 <- sum((L1 - L2) ^ 2) / n
    term.2 <- (sum(L1 - L2) / n) ^ 2
    omega <- sqrt(term.1 - term.2)
    denominator <- omega * sqrt(n)
    vuong.stat <- numerator / denominator
    p.vuong <- pnorm(vuong.stat)
    if (vuong.stat > 0 & p.vuong < alpha) {
        mod.pref <- "Model 1 is preferred."
    } else if (vuong.stat < 0 & p.vuong < alpha) {
        mod.pref <- "Model 2 is preferred."
    } else {
        mod.pref <- paste("Cannot distinguish between models at p =",
                            alpha, "level.")
    }
    return(list(Vuong = vuong.stat, p = p.vuong, pref = mod.pref))
}

#########################
# Plots for local logit #
#########################

plotvals.out <- function(X.mat, Y, bw.par, plot.var,
                        lo.var = min(X.mat[,plot.var]),
                        hi.var = max(X.mat[,plot.var]),
                        n.plot = 1000, app.fn = median, nwork = 4,
                        q1, q2, q3, tval = 1.96) {
    k <- ncol(X.mat)
    change.var <- seq(from = lo.var, to = hi.var, length.out = n.plot)

    if (is.numeric(app.fn)) {
        X.c <- app.fn
                            # If the user inputs a vector for app.fn,
                            # we will just repeat that vector.
                            # The vector should be of length k-1.
    } else {
        X.c <- apply(X.mat, 2, app.fn)
                            # If the user inputs a character string instead,
                            # apply that function to the X matrix.
    }

    mat.c <- matrix(rep(X.c, each = n.plot), nrow = n.plot)
    mat.c[,plot.var] <- change.var

    require(doSMP)
    require(matrixStats)
    capture.output(rmSessions(all = T),file = 'NUL')
    workers <- startWorkers(nwork)
    registerDoSMP(workers)

    pp <- vector(length = n.plot)
    ci.lo <- vector(length = n.plot)
    ci.hi <- vector(length = n.plot)

    list.mod <- list()
    length(list.mod) <- n.plot

    list.mod <- foreach(i = c(1 : nrow(mat.c)),
                        .packages = "matrixStats",
                        .export = c("cont.fn", "kernel.fn", "ord.fn",
                                    "unord.fn")) %dopar% {
                            kernel.wt <- (cont.fn(q1, X.mat, i, bw.par[1],
                                            mat.c) *
                                        ord.fn(q1, q2, X.mat, i, bw.par[2],
                                            mat.c) *
                                        unord.fn(q3, X.mat, i, bw.par[3],
                                            mat.c))
                            glm(Y ~ X.mat, weights = kernel.wt,
                                family = binomial(link = "logit"))
                        }
    stopWorkers(workers)

    betas <- t(sapply(list.mod, function(x) x$coef))
    xb <- rowSums(cbind(1,mat.c)*betas, na.rm = T)
    predprobs <- plogis(xb)
    term.1 <- (predprobs^2)*(1-predprobs)^2

    se.vec <- vector(length = n.plot)
    for (i in (1 : length(list.mod))) {
            vhat <- vcov(list.mod[[i]])
            term.2 <- t(as.matrix(cbind(1,mat.c)[i,])) %*% vhat %*%
                        as.matrix(cbind(1,mat.c)[i,])
            se.vec[i] <- sqrt(term.1[i] * term.2)
        }

    ci.lo <- plogis(xb - tval * se.vec)
    ci.hi <- plogis(xb + tval * se.vec)
    return(list(probs = predprobs, change = change.var, lo = ci.lo, hi = ci.hi))
}


delta.bin <- function(Y, X, betas, varcov, plot.var,
                        lo.var = min(X[,plot.var]),
                        hi.var = max(X[,plot.var]),
                        n.plot = 1000, app.fn = median, link) {
    if (any(X[,1] != 1)) {
        X <- cbind(1, X)
                            # Put in a constant if one isn't there already.
        plot.var <- plot.var + 1
                            # Need to change plot.var if we add a column.
    }
    k <- ncol(X)
    change.var <- seq(from = lo.var, to = hi.var, length.out = n.plot)

    if (is.numeric(app.fn)) {
        X.c <- app.fn
                            # If the user inputs a vector for app.fn,
                            # we will just repeat that vector.
                            # The vector should be of length k-1.
    } else {
        X.c <- apply(X, 2, app.fn)
                            # If the user inputs a character string instead,
                            # apply that function to the X matrix.
    }

    if (ncol(X) > length(X.c)) {
        X.c <- c(1, X.c)
                            # This adds the 1 to X.c if we need it.
    }

    mat.c <- matrix(rep(X.c, each = n.plot), nrow = n.plot)
    mat.c[,plot.var] <- change.var

    xb <- mat.c %*% betas

    if (link == "logit") {
        predprobs <- plogis(xb)
        deriv <- dlogis(xb)
    } else if (link == "probit") {
        predprobs <- pnorm(xb)
        deriv <- dnorm(xb)
    } else {
        cat('Only Logit and Probit supported so far. \n')
    }

    deriv.mat <- sweep(mat.c, 1, deriv, '*')
    vhat <- varcov
    var.pp <- deriv.mat %*% vhat %*% t(deriv.mat)
    se.pp <- sqrt(diag(var.pp))

    ci.lo <- plogis(xb - 1.96 * se.pp)
    ci.hi <- plogis(xb + 1.96 * se.pp)

    return(list(lo = ci.lo, probs = predprobs, hi = ci.hi, change = change.var))
}

plot.threevals <- function(out.1, out.2, out.3, col.1 = "red", col.2 = "blue",
                            col.3 = "darkgreen", plot.title = "Plot",
                            x.axis = "Change", y.axis = "Probabilities",
                            y.lim = NULL, x.ticks = NULL) {
    if (is.null(y.lim)) {
        y.lim <- c(min(out.1$lo, out.2$lo, out.3$lo),
                    max(out.1$hi, out.2$hi, out.3$hi))
    }
    plot(out.1$change, out.1$probs, type = "l", ylim = y.lim, col = col.1,
        lwd = 2, main = plot.title, xlab = x.axis, ylab = y.axis, lty = 1,
        xaxp = x.ticks)
    polygon(c(out.1$change, rev(out.1$change)),c(out.1$lo, rev(out.1$hi)),
        col=rgb(1,0,0,alpha=0.25), border=rgb(1,0,0,alpha=0.25))
    lines(out.2$change, out.2$probs, col = col.2, lwd = 2, lty = 2)
    polygon(c(out.2$change, rev(out.2$change)),c(out.2$lo, rev(out.2$hi)),
        col=rgb(0,0,1,alpha=0.25), border=rgb(0,0,1,alpha=0.25))
    lines(out.3$change, out.3$probs, col = col.3, lwd = 2, lty = 3)
    polygon(c(out.3$change, rev(out.3$change)),c(out.3$lo, rev(out.3$hi)),
        col=rgb(0,1,0,alpha=0.25), border=rgb(0,1,0,alpha=0.25))
}
