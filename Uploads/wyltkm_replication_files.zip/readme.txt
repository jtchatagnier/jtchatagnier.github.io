+-------------------------------------------------+
| This file contains instructions for             |
| replicating the analysis in:                    |
|                                                 |
| "Would You Like to Know More? Selection,        |
| Socialization, and the Political Attitudes      |
| of Military Veterans"                           |    
|                                                 |
| By J. Tyson Chatagnier and Jonathan D. Klingler |
|                                                 |
| Forthcoming in Political Research Quarterly     |
|                                                 |
| File created 18 July 2022                       |
+-------------------------------------------------+

Contents
=========

 * wyltkm_appendix.pdf
   - PDF containing supplementary information and additional analyses not presented in the body of the article
 * wyltkm_replication.R
   - R file used to replicate the results from the body of the article (lines 1--1151) and the appendix (lines 1152--1646)
 * wyltkm_replication_data.csv
   - Comma-separated values file, containing necessary information to replicate the analysis in the main text and appendix

Necessary Software
==================

 * R (analysis performed on R for Windows, v. 4.1.3)
 * R packages:
   - psych
   - tidyverse
   - MatchIt
   - cobalt
   - sensemakr
   - texreg
   - ggplot2

Instructions
=============

1. Extract files to the relevant directory
2. Open wyltkm_replication.R and insert directory information if necessary
3. Run file to replicate results (output will appear on screen in most cases)