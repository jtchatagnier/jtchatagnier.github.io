+-------------------------------------------+
| This file contains instructions for       |
| replicating the analysis in:              |
|                                           |
| "The Power to Hurt and the Effectiveness  |
| of International Sanctions"               |
|                                           |
| By Kerim Can Kavakli,                     |
| J. Tyson Chatagnier,                      |
| and Emre Hatipoglu                        |
|                                           |
| Forthcoming in the Journal of Politics    |
|                                           |
| File created 25 January 2019              |
+-------------------------------------------+

Contents
=========

  Replication Code
  ----------------
  * power2hurt_replication.do
   - Stata .do file used to replicate tables in the main text and appendix
  * power2hurt_plots.r
   - R file used to generate plots in the main text and appendix
   - NOTE: Replication of local logit plots can be computationally intensive. Code requests the use of
           four cores for parallel processing, by default. This can be adjusted by the user. Code to 
           perform cross-validation in order to obtain bandwidth parameters is included, but commented
           out. User can uncomment these lines to estimate bandwidth parameters, but should be warned
           that the process is extremely time consuming, even when using parallel processing.

  Data
  ----
  * power2hurt_JOP_replication_dataset.dta
   - Stata 13 .dta file, containing necessary information to replicate the analysis in the main text and most tables in the appendix
   - This is the primary data set
  * power2hurt_JOP_replication_dataset_Table_A2_Model_1.dta
   - Stata 13 .dta file, containing necessary information to replicate column 1 of appendix Table A2
   - This data set calculates sender coalition power using only a subset of IGOs
  * power2hurt_JOP_replication_dataset_Table_A2_Model_2.dta
   - Stata 13 .dta file, containing necessary information to replicate column 2 of appendix Table A2
   - This data set calculates sender coalition power using only primary senders
  * power2hurt_JOP_replication_dataset_Table_A5.dta
   - Stata 13 .dta file, containing necessary information to replicate appendix Table A5
   - This data set 
  * power2hurt_JOP_replication_dataset_Table_A8.dta
   - Stata 13 .dta file, containing necessary information to replicate appendix Table A8
  * sq_observations.dta
   - Stata .dta file containing data for potential status quo cases, for use in replicating Figure A2 in the appendix
  * power_elasticity.dta
   - Stata .dta file containing data on market power and estimated elasticity, for use in replicating Figure A7 in the appendix

  Auxiliary Files
  ---------------
  * auxiliary_functions.r
   - R code containing user-written functions for use with power2hurt_plots.r
  * beta_model3.txt
   - Text file containing coefficient estimates from Table 1, Model 3, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_model4.txt
   - Text file containing coefficient estimates from Table 1, Model 4, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_model5.txt
   - Text file containing coefficient estimates from Table 1, Model 5, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_model3.txt
   - Text file containing coefficient estimates from Table 1, Model 3, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_a4_m1.txt
   - Text file containing coefficient estimates from Table A4, Model 1, for use in replicating Figure A1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_a9_m1.txt
   - Text file containing coefficient estimates from Table A9, Model 1, for use in replicating Figure A5
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_a9_m5.txt
   - Text file containing coefficient estimates from Table A9, Model 5, for use in replicating Figure A5
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_a10_m1.txt
   - Text file containing coefficient estimates from Table A10, Model 1, for use in replicating Figure A6
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * beta_a10_m5.txt
   - Text file containing coefficient estimates from Table A10, Model 5, for use in replicating Figure A6
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * vcov_model3.txt
   - Text file containing estimated covariance matrix from Table 1, Model 3, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * vcov_model4.txt
   - Text file containing estimated covariance matrix from Table 1, Model 4, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * vcov_model5.txt
   - Text file containing estimated covariance matrix from Table 1, Model 5, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * vcov_model3.txt
   - Text file containing estimated covariance matrix from Table 1, Model 3, for use in replicating Figure 1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results
  * vcov_a4_m1.txt
   - Text file containing estimated covariance matrix from Table A4, Model 1, for use in replicating Figure A1
   - File is provided for convenience; estimates can be obtained by running power2hurt_replication.do and exporting results

  Other
  -----
  * market_power_appendix.pdf
   - PDF containing supplementary information and additional analyses not presented in the body of the article


Necessary Software
==================

* Stata (analysis performed using Stata/SE 14.2 for Windows)
* R (analysis performed using R for Windows, v. 3.4.3)
* R packages:
  - readstata13
  - ggplot2
  - verification
  - reshape2
  - matrixStats
  - doParallel
  - foreach
  - matrixStats
  - grid

Instructions
=============

1. Extract files to the relevant directory
2. Open power2hurt_replication.do in Stata, and insert directory information if necessary
3. Run file to replicate tables within the main text and appendix
4. Open power2hurt_plots.r in R, and insert directory information if necessary
5. Run file to replicate plots within the main text and appendix