+------------------------------------------------------+
| This file contains instructions for replicating the  |
| analysis in:                                         |
|                                                      |
| "The internationalization of production and          |
| compliance in WTO disputes                           |
|                                                      |
| By Aydin Yildirim, J. Tyson Chatagnier,              |
| Arlo Poletti, and Dirk De Bievre                     |
|                                                      |
| Forthcoming in Review of International Organizations |
|                                                      |
| File created 10 March 2017                           |
+------------------------------------------------------+

Contents
=========

 * ipc_online_appendix.docx
   - Word document, containing supplementary information and additional analyses not presented in the body of the article
 * wto_compliance_wiod.csv
   - Excel CSV file, containing information on WTO compliance, using data from the World Input-Output Database
     (See: http://www.wiod.org/home)
 * wto_compliance_tiva.csv
   - Excel CSV file, containing information on WTO compliance, using data from the Trade in Value Added Database
     (See: http://www.oecd.org/sti/ind/measuringtradeinvalue-addedanoecd-wtojointinitiative.htm)
 * ipc_auxiliary_functions.r
   - R file containing auxiliary functions that will be used by other files
 * ipc_rio_replication.r
   - R file used to replicate the results from the body of the article
 * ipc_rio_appendix.r
   - R file used to replicate results from the online appendix

Instructions
=============

1. Extract files to the relevant directory
2. Open ipc_rio_replication.r and insert directory information if necessary
3. Run file to replicate results from Table 1, and to create four files:
 - sector_values.pdf (Figure 1)
 - duration_model_results.doc (Table 2)
 - avg_expected_duration_wiod.pdf (Figure 2)
 - two_cases_wiod.pdf (Figure 3)
4. Open ipc_rio_appendix.r and insert directory information if necessary
5. Run file to replicate the information in Table A1, and to generate the following four files:
 - avg_expected_duration_wiod.pdf (Figure A1)
 - two_cases_tiva.pdf (Figure A2)
 - duration_models_no_complexity.doc (Table A2)
 - duration_models_alt_dv.doc (Table A3)


