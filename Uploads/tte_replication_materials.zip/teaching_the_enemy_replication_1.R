#########################################################
# This is a program to replicate part 1 of the          #
# analyses for:                                         #
# Chatagnier, J. Tyson. "Teaching the Enemy: The        #
# Empirical Implications of Bargaining  Under           #
# Observation."                                         #
# Published in: The Journal of Conflict Resolution      #
#                                                       #
# Analysis is written for parallel computing with       #
# a Windows PC, using the doSMP package. As of 2013,    #
# this requires the use of Revolution R for Windows     #
# or the rewriting of the parallel sections for (not    #
# recommended) single-processor computing or for use    #
# with other parallel computing packages.               #
#########################################################

library(foreign)
library(matrixStats)
library(doSMP)
library(verification)

rm(list = ls())

capture.output(rmSessions(all = T),file = 'NUL')
                            # This will remove any currently running
                            # child processes.
                            # The doSMP version has a particular problem
                            # with this.

############################
# Get the llogit functions #
############################

source("~/llogit_functions.R")


############
# The Data #
############

disputes <- read.dta("~/tte_replication_1.dta")

#setwd("~/")
                            # The program includes code to turn images
                            # into PDF files.
                            # These are currently commented out, but can be
                            # included.
                            # This line tells R into which directory to
                            # store the files.


######################################
# Variables to capture p, c1, and c2 #
######################################

disputes$p <- disputes$cap_a / (disputes$cap_a + disputes$cap_b)
                            # This is state A's share of capabilities.
                            # This approximates the probability
                            # of victory for side A.

data.riv <- data.frame(na.omit(cbind(disputes$esc, disputes$p,
                        disputes$tenure_a, disputes$lntrade_a,
                        disputes$lntrade_b, disputes$rivals_a,
                        disputes$xrreg_a, disputes$xrcomp_a,
                        disputes$xconst_a, disputes$parcomp_a,
                        disputes$xrreg_b, disputes$xrcomp_b,
                        disputes$xconst_b, disputes$parcomp_b,
                        disputes$majpow_a, disputes$majpow_b,
                        disputes$contiguity)))
colnames(data.riv) <-c("escalation", "p", "tenure.a", "lntrade.a",
                        "lntrade.b", "rivals.a", "xrreg.a", "xrcomp.a",
                        "xconst.a", "parcomp.a", "xrreg.b", "xrcomp.b",
                        "xconst.b", "parcomp.b", "majpow.a", "majpow.b",
                        "contiguity")

Y.riv <- data.riv[,1]
X.riv <- as.matrix(data.riv)[,-1]

n <- length(Y.riv)
k <- ncol(X.riv)

q1 <- 4
q2 <- 9
q3 <- 3
                            # We have 4 continuous variables, 9 ordered,
                            # and 3 unordered.
n <- length(Y.riv)
k <- ncol(X.riv)


bw.riv <- c(54.72060, 0.7832633, 0.6506724)
                            # These values were obtained from cross-validation
                            # on a 24-node cluster. One can use the
                            # cv.parallel function (see the included
                            # llogit_functions.r file) to estimate these
                            # parameters. The process is extremely resource
                            # intensive, and not replicated here.


#########################
# Create cost profiles. #
#########################

costs.lo <- c(6.701343, 3, 1, 2, 1, 1)
costs.med <- c(median(data.riv$lntrade.a, na.rm = T), 2, 2, 4, 3, 0)
costs.hi <- c(7.799955, 1, 3, 6, 5, 0)
                            # These are the values depicted in Table 1 of the
                            # paper.

costb.med <- c(median(data.riv$lntrade.b, na.rm = T), 2, 2, 4, 3, 0)
                            # State B is held constant at medium costs.

lo.riv <- c(0.5, 1, costs.lo[1], costb.med[1],
            median(data.riv$rivals.a, na.rm = T), costs.lo[2 : 5],
            costb.med[2 : 5], costs.lo[6 : length(costs.lo)],
            costb.med[6 : length(costb.med)], 1)

med.riv <- c(0.5, 1, costs.med[1], costb.med[1],
            median(data.riv$rivals.a, na.rm = T), costs.med[2 : 5],
            costb.med[2 : 5], costs.med[6 : length(costs.med)],
            costb.med[6 : length(costb.med)], 1)

hi.riv <- c(0.5, 1, costs.hi[1], costb.med[1],
            median(data.riv$rivals.a, na.rm = T), costs.hi[2 : 5],
            costb.med[2 : 5], costs.hi[6 : length(costs.hi)],
            costb.med[6 : length(costb.med)], 0)


######################
# Calculate and plot #
# local logit        #
######################
out.riv.hi <- plotvals.out(X.riv, Y.riv, bw.par = bw.riv, plot.var = 5,
                            q1 = q1, q2 = q2, q3 = q3, app.fn = hi.riv)
out.riv.med <- plotvals.out(X.riv, Y.riv, bw.par = bw.riv, plot.var = 5,
                            q1 = q1, q2 = q2, q3 = q3, app.fn = med.riv)
out.riv.lo <- plotvals.out(X.riv, Y.riv, bw.par = bw.riv, plot.var = 5,
                            q1 = q1, q2 = q2, q3 = q3, app.fn = lo.riv)

############
# Figure 1 #
############

#pdf("llogitall.pdf", height = 7, width = 7)
plot.threevals(out.riv.lo, out.riv.med, out.riv.hi,
                plot.title = "Cost of Fighting and Probability of War",
                x.axis = "Number of Rivals",
                y.axis = "Probability of Escalation", y.lim = c(0, 0.9),
                x.ticks = c(0, 8, 8))
legend(0, 0.5, lwd = 2, col = c("red", "blue", "darkgreen"),
        legend = c("Low Cost", "Medium Cost", "High Cost"), lty = c(1, 2, 3))
#dev.off()


##########################
# Calculate and plot     #
# parametric logit.      #
##########################

logit.riv <- glm(Y.riv ~ X.riv, family = binomial(link = "logit"))

riv.lo.logit <- delta.bin(Y = Y.riv, X = X.riv, betas = logit.riv$coef,
                            varcov = vcov(logit.riv), plot.var = 5,
                            n.plot = 1000, app.fn = lo.riv, link = "logit")

riv.med.logit <- delta.bin(Y = Y.riv, X = X.riv, betas = logit.riv$coef,
                            varcov = vcov(logit.riv), plot.var = 5,
                            n.plot = 1000, app.fn = med.riv, link = "logit")

riv.hi.logit <- delta.bin(Y = Y.riv, X = X.riv, betas = logit.riv$coef,
                            varcov = vcov(logit.riv), plot.var = 5,
                            n.plot = 1000, app.fn = hi.riv, link = "logit")

############
# Figure 2 #
############

#pdf("logit.pdf", height = 7, width = 7)
plot.threevals(out.1 = riv.lo.logit, out.2 = riv.med.logit,
                out.3 = riv.hi.logit,
                plot.title = "Cost of Fighting and Probability of War",
                x.axis = "Number of Rivals",
                y.axis = "Probability of Escalation", y.lim = c(0, 0.9),
                x.ticks = c(0, 8, 8))
legend(5, 0.4, lwd = 2, col = c("red", "blue", "darkgreen"),
        legend = c("Low Cost", "Medium Cost", "High Cost"), lty = c(1, 2, 3))
#dev.off()


###################
# Make ROC Curves #
###################

#################
# Within Sample #
#################

mat.riv <- betas.out(Y = Y.riv, X = X.riv, bw = bw.riv, q1 = q1, q2 = q2,
            q3 = q3, nwork = 4)

xb.riv <- rowSums(cbind(1,X.riv) * mat.riv)
                            # This gives us the scalar, xbeta,
                            # for each observation.
pp.riv <- 1 / (1 + exp(-xb.riv))
                            # Get predicted probabilities

xb.logit.riv <- cbind(1, X.riv) %*% logit.riv$coef
                            # We've already calculated the coefficients
                            # for the parametric logit.
pp.logit.riv <- 1 / (1 + exp(-xb.logit.riv))

#############################
# Out of Sample Predictions #
#############################

bw.oos <- c(39.67738, 0.8005885, 0.6494717)
                            # Parameters come from cross-validation with
                            # 90% of observations.

set.seed(244546)
                            # Since we will be randomly sampling,
                            # the seed ensures replicability.

data.samp <- sample(nrow(data.riv), nrow(data.riv) * .1, replace = F)
                            # Randomly drop 10% of the rows.

data.oos <- data.riv[-data.samp, ]
Y.oos <- data.oos[,1]
X.oos <- as.matrix(data.oos[, -1])

profiles.oos <- X.riv[data.samp, ]
esc.oos <- Y.riv[data.samp]
                            # Profiles should come from the 10% of
                            # omitted rows, but the estimation
                            # will be done using the other 90%.

mat.oos <- betas.out(Y = Y.oos, X = X.oos, bw = bw.oos, q1 = q1, q2 = q2,
                    q3 = q3, profiles = profiles.oos, nwork = 4)

xb.oos <- rowSums(cbind(1,profiles.oos) * mat.oos)
                            # This gives us the scalar, xbeta, for each
                            # observation.
pp.oos <- 1 / (1 + exp(-xb.oos))
                            # Get predicted probabilities

logit.oos <- glm(Y.oos ~ X.oos, family = binomial(link = "logit"))
                            # Do the same thing with the parametric
                            # logit on the OOS data.

xb.logit.oos <- cbind(1, profiles.oos) %*% logit.oos$coef
pp.logit.oos <- 1 / (1 + exp(-xb.logit.oos))

############
# Figure 3 #
############

#pdf("ROCplot.pdf", height = 7, width = 7)
roc.plot(Y.riv, cbind(pp.logit.riv, pp.riv),show.thres=F, legend = F,
        xlab = "False Positive Rate", ylab = "True Positive Rate", main = "")
legend(0.6, 0.45, lwd = 2, col = c("black", "red"),
        legend = c("Logit", "Local Logit"), lty = c(1, 2))
                                                # This is the left panel.
#dev.off()

#pdf("ROCplotoos.pdf", height = 7, width = 7)
roc.plot(esc.oos, cbind(pp.logit.oos,pp.oos),show.thres=F, legend = F,
        xlab = "False Positive Rate", ylab = "True Positive Rate", main = "")
legend(0.6, 0.45, lwd = 2, col = c("black", "red"),
        legend = c("Logit", "Local Logit"), lty = c(1, 2))
                                                # This is the right panel.
#dev.off()


##########################################
# Vuong Test on Out-of-Sample Prediction #
##########################################

lik.logit <- lik.fn(esc.oos, pp.logit.oos)
lik.llogit <- lik.fn(esc.oos, pp.oos)

vuong.test(L1 = lik.logit, L2 = lik.llogit, K1 = ncol(X.oos),
            K2 = ncol(X.oos), n = length(Y.oos))
