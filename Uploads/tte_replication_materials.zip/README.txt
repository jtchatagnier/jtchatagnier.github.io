---------------
---------------

This file includes the materials to replicate the analyses in:

Chatagnier, J. Tyson. "Teaching the Enemy: The Empirical Implications of Bargaining Under Observation." 
Published in: The Journal of Conflict Resolution.

---------------
---------------

Data files:
-----------

tte_replication_1.dta:	Data file for replication of part 1 of the analysis (H1 and H2)
tte_replication_2.dta:	Data file for replication of part 2 of the analysis (H3)

---------------
---------------

Replication files:
------------------

llogit_functions.R: necessary functions for analysis, called by first replication program
duration_functions.R: necessary functions for analysis, called by second replication program
teaching_the_enemy_replication_1.R:	R code for replication of escalation analysis (H1 and H2)
teaching_the_enemy_replication_2.R:	R code for replication of duration analysis (H3)

---------------
---------------

Notes
-----

All code is written for Revolution R version 6.0 on a Windows PC
Data files are in Stata .dta format
Replication requires replacement of ~ in file path with directory name

*IMPORTANT* 
Because of the computational intensity of the local logit procedure, code is written to take
advantage of parallel processing, using the doSMP package. As of 2013, this package has been
discontinued for all distributions of R with the exception of Revolution R. Replication on 
anything other than a Windows system running Revolution R will require some adjustment of 
the code either to use doMC (for Mac or Linux) or doSNOW (for cluster computing). 