##################################################
# Code to replicate results in the appendix for: #
#                                                #
# "The internationalization of production and    #
# compliance in WTO disputes"                    #
#                                                #
# Aydin Yildirim, J. Tyson Chatagnier,           #
# Arlo Poletti, and Dirk De Bievre               #
#                                                #
# Forthcoming in the Review of International     #
# Organizations                                  #
#                                                #
# File created 10 March 2017                     #
##################################################

rm(list = ls())

library(ggplot2)
library(survival)
library(texreg)
library(gridExtra)
library(reshape)

# setwd("")
                        # Uncomment and add path to change working directory

source("ipc_auxiliary_functions.r")
                        # Auxiliary file to be sourced

set.seed(2016)
                        # Set seed for replication purposes

#################
# Read in data. #
#################

wiod <- read.csv("wto_compliance_wiod.csv")

list.names <- c("id",
                "defendant",
                "name",
                "date",
                "litigant",
                "industry",
                "dev.lit",
                "dev.def",
                "compliance",
                "complytime.new",
                "complytime",
                "complytime.days",
                "polity.def",
                "polity.lit",
                "ag",
                "eu",
                "usa",
                "def.exp.share",
                "complex",
                "gdp.def",
                "gdp.comp",
                "lngdp.def",
                "lngdp.comp",
                "power.gdp", 
                "sector.output",
                "sec.cons",
                "imp.dep",
                "sec.val",
                "sec.val.per",
                "fdi.out",
                "fdi.in.comp",
                "fdi.share",
                "veto"
                )

colnames(wiod) <- list.names

tiva <- read.csv("wto_compliance_tiva.csv")

list.names <- c("id",
                "defendant",
                "name",
                "date",
                "litigant",
                "industry",
                "dev.lit",
                "dev.def",
                "compliance",
                "complytime.new",
                "complytime",
                "complytime.days",
                "polity.def",
                "polity.lit",
                "ag",
                "eu",
                "usa",
                "def.exp.share",
                "complex",
                "gdp.def",
                "gdp.comp",
                "lngdp.def",
                "lngdp.comp",
                "power.gdp", 
                "sector.output",
                "sec.int",
                "int.imp",
                "sec.imp",
                "imp.dep",
                "foreign.exp",
                "sec.val",
                "sec.val.per",
                "fdi.out",
                "fdi.in.comp",
                "fdi.share",
                "veto"
                )

colnames(tiva) <- list.names

##############################
# Make necessary adjustments #
# to the two data sets       #
##############################

wiod$dem.lo <- ifelse(wiod$polity.def > wiod$polity.lit,
                      wiod$polity.lit,
                      wiod$polity.def
                      )
                        # Create a variable for dyadic democracy

wiod$dem.hi <- ifelse(wiod$polity.def < wiod$polity.lit,
                      wiod$polity.lit,
                      wiod$polity.def
                      )
                        # Create a variable for higher democracy level

wiod$year <- as.character(wiod$date)

wiod$year[1 : 85] <- substr(wiod$year[1 : 85], 
                            1 , 
                            4
                            )

wiod$year[86 : length(wiod$year)] <- substrRight(wiod$year[86 : length(wiod$year)], 
                                                2
                                                )

wiod$year <- ifelse(as.numeric(wiod$year) < 100,
                    ifelse(as.numeric(wiod$year) > 50,
                           paste("19",
                                 wiod$year,
                                 sep = ""
                                 ),
                           paste("20",
                                 wiod$year,
                                 sep = ""
                                 )
                           ),
                    wiod$year
                    )

wiod$year <- as.numeric(wiod$year)
                        # Get the year for each of the observations.
                        # NOTE: this hard codes the observation numbers, based
                        # on present spreadsheet. If data are updated, THIS
                        # SECTION OF CODE MUST BE CHANGED AS WELL.

wiod$year.fac <- factor(ifelse(wiod$year == 2004,
                               2005,
                               wiod$year
                               )
                        )
                        # Create a factor variable for the year. Group 
                        # 2004 with 2005 because it gives us problems:
                        # there are no uncensored, complete observations in 
                        # 2004. Grouping it with 2005, rather than 2003,
                        # because the expiration of the Peace Clause matters.

wiod$lnsec.val <- log(as.numeric(wiod$sec.val))
                        # Log this because it's so much different from the
                        # rest of the variables in terms of scale

wiod$complytime.new <- as.numeric(as.character(wiod$complytime.new))
                        # Turn this into a numeric, rather than factor variable.

wiod[wiod == -99] <- NA
tiva[tiva == -99] <- NA
                        # Turn -99s into NAs.

tiva$dem.lo <- ifelse(tiva$polity.def > tiva$polity.lit,
                      tiva$polity.lit,
                      tiva$polity.def
                      )
                        # Create a variable for dyadic democracy
tiva$dem.hi <- ifelse(tiva$polity.def < tiva$polity.lit,
                      tiva$polity.lit,
                      tiva$polity.def
                      )
                        # Create a variable for higher democracy level

tiva$year <- as.character(tiva$date)
tiva$year <- substr(tiva$year, 
                    1 , 
                    4
                    )
tiva$year <- as.numeric(tiva$year)

tiva$year.fac <- factor(ifelse(tiva$year == 2004,
                               2005,
                               tiva$year
                               )
                        )
                        # Create a factor variable for the year. Group 
                        # 2004 with 2005 because it gives us problems:
                        # there are no uncensored, complete observations in 
                        # 2004. Grouping it with 2005, rather than 2003,
                        # because the expiration of the Peace Clause matters.

tiva$lnsec.val <- log(tiva$sec.val)
                        # Log this because it's so much different from the
                        # rest of the variables in terms of scale
tiva$complytime.new <- as.numeric(as.character(tiva$complytime.new))
                        # Turn this into a numeric, rather than factor variable.


############
# Table A1 #
############

vars <- with(tiva,
             cbind(complytime, imp.dep, int.imp, foreign.exp, 
                   polity.def, def.exp.share, lnsec.val, veto, fdi.share
                   )
             )

min.vars <- apply(vars,
                  2,
                  min,
                  na.rm = T
                  )

max.vars <- apply(vars,
                  2,
                  max,
                  na.rm = T
                  )

mean.vars <- apply(vars,
                   2,
                   mean,
                   na.rm = T
                   )

sd.vars <- apply(vars,
                 2,
                 sd,
                 na.rm = T
                 )

df.vars <- data.frame(Minimum = round(min.vars, 
                                      digits = 2
                                      ),
                      Maximum = round(max.vars, 
                                      digits = 2
                                      ),
                      Mean    = round(mean.vars, 
                                      digits = 2
                                      ),
                      SD      = round(sd.vars, 
                                      digits = 2
                                      )
                      )

rownames(df.vars) <- c("Months to compliance",
                       "Import Dependence",
                       "Intermediate Import Dependence",
                       "Foreign Exports",
                       "Defendant polity score",
                       "Defendant export dependence",
                       "Sector value added",
                       "Veto players",
                       "FDI share"
                       )

df.vars
                        # This reproduces Table A1 in the appendix

############################
# Plot substantive results #
# from TiVA analysis       #
############################

tiva$comply.surv <- Surv(tiva$complytime, 
                         tiva$compliance
                         )

mod.int <- coxph(comply.surv ~ polity.def + def.exp.share + 
                               complex + lnsec.val + veto + fdi.share + 
                               eu + usa + int.imp + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

###################
# Average effects #
###################

min.exp <- min(wto$int.imp,
               na.rm = TRUE
               )

max.exp <- max(wto$int.imp,
               na.rm = TRUE
               )

int.vals <- seq(from       = 1.68,
                to         = 39.18,
                length.out = 1000
                )
                        # Plot over the range used in the WIOD graph

mat.pred <- matrix(nrow = length(int.vals),
                   ncol = 3
                   )

for (i in 1 : length(int.vals)) {
  boot.vals <- BootDur(mod      = mod.int,
                       var      = "int.imp",
                       vals     = int.vals[i],
                       se       = TRUE
                       )
  mat.pred[i, ] <- c(boot.vals$point, 
                     boot.vals$point - boot.vals$se, 
                     boot.vals$point + boot.vals$se
                     )
  cat("Iteration", i, "of", length(int.vals), "complete.\n")
}

dur.df <- data.frame(Duration = mat.pred[, 1],
                     Change   = int.vals,
                     Lo       = mat.pred[, 2],
                     Hi       = mat.pred[, 3]
                     )

pdf("avg_expected_duration_tiva.pdf")
  ggplot(data = dur.df,
         aes(x = Change,
             y = Duration
             )
         ) +
    geom_ribbon(aes(ymin = Lo,
                    ymax = Hi
                    ),
                alpha  = 0.3,
                colour = "darkgray"
                ) +
    geom_line(size   = 1.10,
              colour = "navyblue"
              ) +
    xlab("Import Dependence") +
    ylab("Expected Time Until Compliance (in Months)") +
    theme_bw()
dev.off()

##################
# Specific cases #
##################
tiva.nona <- tiva[complete.cases(vars), ]
                        # The vars object contains all of the non-dummy
                        # variables of interest for our analysis. We can
                        # use this to remove the relevant NA rows from our
                        # larger data set

cases <- c(23, 37)

case.names <- c("Biotech Marketing",
                "Gasoline Standards"
                )
                        # Need to change this if the cases change

titles <- paste(tiva.nona$litigant[cases],
                "-",
                tiva.nona$defendant[cases],
                " ",
                case.names,
                " (",
                tiva.nona$year[cases],
                ")",
                sep = ""
                )

plot.lo <- PlotDur(mod  = mod.int,
                   vec  = mod.int$x[23, ],
                   var  = "int.imp",
                   vals = seq(0, 50),
                   boot = FALSE
                   )

plot.hi <- PlotDur(mod  = mod.int,
                   vec  = mod.int$x[37, ],
                   var  = "int.imp",
                   vals = seq(0, 50),
                   boot = FALSE
                   )

p.lo <- plot.lo +
          geom_point(aes(x = tiva.nona$int.imp[23],
                         y = tiva.nona$complytime[23]
                         ),
                     size   = 5,
                     colour = "red"
                     ) +
          xlab("Import Dependence") +
          ylab("Expected Time Until Compliance (in Months)") +
          ggtitle(titles[1]) +
          theme_bw()

p.hi <- plot.hi +
          geom_point(aes(x = tiva.nona$int.imp[37],
                         y = tiva.nona$complytime[37]
                         ),
                     size   = 5,
                     colour = "red"
                     ) +
          xlab("Import Dependence") +
          ylab("Expected Time Until Compliance (in Months)") +
          ggtitle(titles[2]) +
          theme_bw()

#############
# Figure A2 #
#############

pdf("two_cases_tiva.pdf",
    width  = 16,
    height = 8
    )
  grid.arrange(p.lo, 
               p.hi, 
               ncol = 2
               )
dev.off()
  
###########################
# Robustness with respect #
# to issue complexity     #
###########################

#########################
# Calculate correlation #
#########################

cor.wiod <- cor(cbind(wiod$complytime, 
                      wiod$complex
                      ),
                use = "complete.obs"
                )[1, 2]
                        # Correlation between time to compliance and
                        # issue complexity is relatively low and
                        # negative (r < -0.26)

cor.wiod <- round(cor.wiod,
                digits = 4
                )

#########################
# Create jittered plots #
# to show correlations  #
#########################

wiod.df <- data.frame(ComplyTime = wiod$complytime,
                      Complexity = jitter(wiod$complex)
                      )

pdf("complexity_plot.pdf")
  ggplot(data = wiod.df,
         aes(y = ComplyTime,
             x = Complexity
             )
         ) +
    geom_point(colour = "navyblue") +
    geom_smooth(method = lm) +
    ylab("Months to Compliance") +
    xlab("Issue Complexity") +
    ggtitle("Relationship between Issue Complexity\nand Time to Compliance (WIOD)") +
    annotate(geom  = "text",
             y     = 125,
             x     = 0.65,
             size  = 6,
             label = paste("r = ", 
                           cor.wiod
                           )
             ) +
    scale_x_continuous(breaks = c(0, 
                                  1
                                  ),
                       labels = c("Complex", 
                                  "Non-Complex"
                                  )
                       ) +
    theme_bw()
dev.off()

#####################
# Now, run analysis #
# with complexity   #
# excluded          #
#####################

wiod$comply.surv <- Surv(wiod$complytime, 
                         wiod$compliance
                         )

nocomplex.base <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                      lnsec.val + veto + fdi.share +
                                      eu + usa,
                        data = wiod,
                        x    = TRUE
                        )

nocomplex.dep <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                    lnsec.val + veto + fdi.share + 
                                    eu + usa + imp.dep,
                       data = wiod,
                       x    = TRUE
                       )  

nocomplex.time <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                      lnsec.val + veto + fdi.share + 
                                      eu + usa + imp.dep + year.fac,
                        data = wiod,
                        x    = TRUE
                        )  

nocomplex.imp <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                     lnsec.val + veto + fdi.share + 
                                     eu + usa + imp.dep + year.fac,
                       data = tiva,
                       x    = TRUE
                       )  

nocomplex.int <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                     lnsec.val + veto + fdi.share + 
                                     eu + usa + int.imp + year.fac,
                       data = tiva,
                       x    = TRUE
                       )  

nocomplex.exp <- coxph(comply.surv ~ polity.def + def.exp.share + 
                                     lnsec.val + veto + fdi.share + 
                                     eu + usa + foreign.exp + year.fac,
                       data = tiva,
                       x    = TRUE
                       )  

#################
# Write results #
#################

############
# Table A2 #
############

write(htmlreg(list(nocomplex.base,
                   nocomplex.dep,
                   nocomplex.time,
                   nocomplex.imp,
                   nocomplex.int,
                   nocomplex.exp
                   ),
              stars              = c(0.01, 
                                     0.05, 
                                     0.10
                                     ),
              omit.coef          = "year.fac",
              custom.model.names = c("Baseline",
                                     "Integration Included",
                                     "Time Included",
                                     "Import Dep.",
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     ),
              custom.coef.names  = c("Defendant Democracy",
                                     "Def. Export Dependence",
                                     "Sectoral Value Added",
                                     "Veto Players",
                                     "Share of FDI Stocks",
                                     "EU Defendant",
                                     "US Defendant",
                                     "Import Dependence",
                                     names(coef(nocomplex.time))[9 : 22],
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     )
        ),
        file = "duration_model_no_complexity.doc"
)
                        # This outputs the six models as HTML, and
                        # writes them to a .doc file.

##########################
# New dependent variable #
##########################

wiod$new.surv <- Surv(wiod$complytime.new, 
                      wiod$compliance
                      )
tiva$new.surv <- Surv(tiva$complytime.new, 
                      tiva$compliance
                      )
                        # The TiVA version of the alternative DV is
                        # a factor variable, so convert to numeric

mod.base <- coxph(new.surv ~ polity.def + def.exp.share + 
                             complex + lnsec.val + veto + fdi.share +
                             eu + usa,
                  data = wiod,
                  x    = TRUE
                  )

mod.dep <- coxph(new.surv ~ polity.def + def.exp.share + 
                            complex + lnsec.val + veto + fdi.share + 
                            eu + usa + imp.dep,
                  data = wiod,
                  x    = TRUE
                  )  

mod.time <- coxph(new.surv ~ polity.def + def.exp.share + 
                             complex + lnsec.val + veto + fdi.share + 
                             eu + usa + imp.dep + year.fac,
                  data = wiod,
                  x    = TRUE
                  )  

mod.imp <- coxph(new.surv ~ polity.def + def.exp.share + 
                            complex + lnsec.val + veto + fdi.share + 
                            eu + usa + imp.dep + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

mod.int <- coxph(new.surv ~ polity.def + def.exp.share + 
                            complex + lnsec.val + veto + fdi.share + 
                            eu + usa + int.imp + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

mod.exp <- coxph(new.surv ~ polity.def + def.exp.share + 
                            complex + lnsec.val + veto + fdi.share + 
                            eu + usa + foreign.exp + year.fac,
                 data = tiva,
                 x    = TRUE
                 )  

############
# Table A3 #
############

write(htmlreg(list(mod.base,
                   mod.dep,
                   mod.time,
                   mod.imp,
                   mod.int,
                   mod.exp
                   ),
              stars              = c(0.01, 
                                     0.05, 
                                     0.10
                                     ),
              omit.coef          = "year.fac",
              custom.model.names = c("Baseline",
                                     "Integration Included",
                                     "Time Included",
                                     "Import Dep.",
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     ),
              custom.coef.names  = c("Defendant Democracy",
                                     "Def. Export Dependence",
                                     "Issue Complexity",
                                     "Sectoral Value Added",
                                     "Veto Players",
                                     "Share of FDI Stocks",
                                     "EU Defendant",
                                     "US Defendant",
                                     "Import Dependence",
                                     names(coef(mod.time))[10 : 23],
                                     "Intermediate Imp. Dep.",
                                     "Foreign Exports"
                                     )
        ),
        file = "duration_models_alt_dv.doc"
)
                        # This outputs the six models as HTML, and
                        # writes them to a .doc file.
