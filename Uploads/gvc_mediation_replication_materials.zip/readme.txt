+-------------------------------------------+
| This file contains instructions for       |
| replicating the analysis in:              |
|                                           |
| "Civil War Mediation and Integration into | 
| Global Value Chains"                      |
|                                           |
| By J. Tyson Chatagnier                    |
|                                           |
| Forthcoming in International Interactions |
|                                           |
| File created 28 September 2018            |
+-------------------------------------------+

Contents
=========

 * mediation_and_gvcs_appendix.pdf
   - PDF containing supplementary information and additional analyses not presented in the body of the article
 * gvc_mediation_replication_data.dta
   - Stata 13 .dta file, containing necessary information to replicate the analysis in the main text and most of the appendix
 * gvc_mediation_replication_data_oecd.dta
   - Stata 13 .dta file, containing necessary information to replicate the OECD portion of the analysis in the appendix
 * gvc_mediation_replication.r
   - R file used to replicate the results from the body of the article (lines 1--535) and the appendix (lines 536--1819)

Necessary Software
==================

* R (analysis performed on R for Windows, v. 3.4.3)
* R packages:
  - readstata13
  - ggplot2
  - texreg
  - countrycode

Instructions
=============

1. Extract files to the relevant directory
2. Open gvc_mediation_replication.r and insert directory information if necessary
3. Run file to replicate results (output will appear on screen)